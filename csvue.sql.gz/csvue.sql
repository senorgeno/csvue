# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.1.44)
# Database: csvue
# Generation Time: 2013-07-07 10:44:41 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table BlogEntry
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogEntry`;

CREATE TABLE `BlogEntry` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogEntry` WRITE;
/*!40000 ALTER TABLE `BlogEntry` DISABLE KEYS */;

INSERT INTO `BlogEntry` (`ID`, `Date`, `Author`, `Tags`)
VALUES
	(36,'2013-07-06 17:25:00',NULL,'silverstripe, blog');

/*!40000 ALTER TABLE `BlogEntry` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogEntry_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogEntry_Live`;

CREATE TABLE `BlogEntry_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogEntry_Live` WRITE;
/*!40000 ALTER TABLE `BlogEntry_Live` DISABLE KEYS */;

INSERT INTO `BlogEntry_Live` (`ID`, `Date`, `Author`, `Tags`)
VALUES
	(36,'2013-07-06 17:25:00',NULL,'silverstripe, blog');

/*!40000 ALTER TABLE `BlogEntry_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogEntry_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogEntry_versions`;

CREATE TABLE `BlogEntry_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogEntry_versions` WRITE;
/*!40000 ALTER TABLE `BlogEntry_versions` DISABLE KEYS */;

INSERT INTO `BlogEntry_versions` (`ID`, `RecordID`, `Version`, `Date`, `Author`, `Tags`)
VALUES
	(1,36,1,'2013-07-06 17:25:00',NULL,'silverstripe, blog');

/*!40000 ALTER TABLE `BlogEntry_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogHolder
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogHolder`;

CREATE TABLE `BlogHolder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `OwnerID` (`OwnerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogHolder` WRITE;
/*!40000 ALTER TABLE `BlogHolder` DISABLE KEYS */;

INSERT INTO `BlogHolder` (`ID`, `AllowCustomAuthors`, `ShowFullEntry`, `OwnerID`)
VALUES
	(35,0,0,0);

/*!40000 ALTER TABLE `BlogHolder` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogHolder_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogHolder_Live`;

CREATE TABLE `BlogHolder_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `OwnerID` (`OwnerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogHolder_Live` WRITE;
/*!40000 ALTER TABLE `BlogHolder_Live` DISABLE KEYS */;

INSERT INTO `BlogHolder_Live` (`ID`, `AllowCustomAuthors`, `ShowFullEntry`, `OwnerID`)
VALUES
	(35,0,0,0);

/*!40000 ALTER TABLE `BlogHolder_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogHolder_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogHolder_versions`;

CREATE TABLE `BlogHolder_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `OwnerID` (`OwnerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogHolder_versions` WRITE;
/*!40000 ALTER TABLE `BlogHolder_versions` DISABLE KEYS */;

INSERT INTO `BlogHolder_versions` (`ID`, `RecordID`, `Version`, `AllowCustomAuthors`, `ShowFullEntry`, `OwnerID`)
VALUES
	(1,35,1,0,0,0);

/*!40000 ALTER TABLE `BlogHolder_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogTree
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogTree`;

CREATE TABLE `BlogTree` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogTree` WRITE;
/*!40000 ALTER TABLE `BlogTree` DISABLE KEYS */;

INSERT INTO `BlogTree` (`ID`, `Name`, `InheritSideBar`, `LandingPageFreshness`)
VALUES
	(35,NULL,1,NULL);

/*!40000 ALTER TABLE `BlogTree` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogTree_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogTree_Live`;

CREATE TABLE `BlogTree_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogTree_Live` WRITE;
/*!40000 ALTER TABLE `BlogTree_Live` DISABLE KEYS */;

INSERT INTO `BlogTree_Live` (`ID`, `Name`, `InheritSideBar`, `LandingPageFreshness`)
VALUES
	(35,NULL,1,NULL);

/*!40000 ALTER TABLE `BlogTree_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table BlogTree_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `BlogTree_versions`;

CREATE TABLE `BlogTree_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `BlogTree_versions` WRITE;
/*!40000 ALTER TABLE `BlogTree_versions` DISABLE KEYS */;

INSERT INTO `BlogTree_versions` (`ID`, `RecordID`, `Version`, `Name`, `InheritSideBar`, `LandingPageFreshness`)
VALUES
	(1,35,1,NULL,1,NULL);

/*!40000 ALTER TABLE `BlogTree_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyCategories`;

CREATE TABLE `CaseStudyCategories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('CaseStudyCategories') CHARACTER SET utf8 DEFAULT 'CaseStudyCategories',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyCategories` WRITE;
/*!40000 ALTER TABLE `CaseStudyCategories` DISABLE KEYS */;

INSERT INTO `CaseStudyCategories` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `url`, `ImageID`)
VALUES
	(1,'CaseStudyCategories','2013-07-06 17:34:45','2013-07-06 17:35:09','Transport','transport',16),
	(2,'CaseStudyCategories','2013-07-06 17:35:38','2013-07-06 17:35:59','Agriculture','agriculture',17),
	(3,'CaseStudyCategories','2013-07-06 17:36:55','2013-07-06 17:37:14','MIning','mining',18),
	(4,'CaseStudyCategories','2013-07-06 17:37:59','2013-07-06 17:38:21','Infrastructure','nfrastructure',19),
	(5,'CaseStudyCategories','2013-07-06 17:38:55','2013-07-06 17:39:06','Oil & Gas','oil-and-gas',20),
	(6,'CaseStudyCategories','2013-07-06 17:39:34','2013-07-06 17:40:15','Local Government','local-government',21),
	(7,'CaseStudyCategories','2013-07-06 17:40:54','2013-07-06 17:41:08','Manufacture & Process','manufacture-and-process',22),
	(8,'CaseStudyCategories','2013-07-06 17:41:43','2013-07-06 17:41:53','Central Government','central-government',23),
	(9,'CaseStudyCategories','2013-07-06 17:42:06','2013-07-06 17:42:29','Defence','defence',24),
	(10,'CaseStudyCategories','2013-07-06 17:42:45','2013-07-06 17:43:05','Services','services',25),
	(11,'CaseStudyCategories','2013-07-06 17:43:23','2013-07-06 17:43:40','Energy','energy',26),
	(12,'CaseStudyCategories','2013-07-06 17:44:04','2013-07-06 17:44:15','Packaging','packaging',27),
	(13,'CaseStudyCategories','2013-07-06 17:44:31','2013-07-06 17:44:42','Resellers','resellers',28);

/*!40000 ALTER TABLE `CaseStudyCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyCategoriesPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyCategoriesPage`;

CREATE TABLE `CaseStudyCategoriesPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyCategoriesPage` WRITE;
/*!40000 ALTER TABLE `CaseStudyCategoriesPage` DISABLE KEYS */;

INSERT INTO `CaseStudyCategoriesPage` (`ID`, `ImageID`)
VALUES
	(37,43),
	(38,44),
	(39,45),
	(40,46),
	(41,47),
	(42,49),
	(43,50),
	(44,51),
	(45,52),
	(46,53),
	(47,54),
	(48,55),
	(49,56);

/*!40000 ALTER TABLE `CaseStudyCategoriesPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyCategoriesPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyCategoriesPage_Live`;

CREATE TABLE `CaseStudyCategoriesPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyCategoriesPage_Live` WRITE;
/*!40000 ALTER TABLE `CaseStudyCategoriesPage_Live` DISABLE KEYS */;

INSERT INTO `CaseStudyCategoriesPage_Live` (`ID`, `ImageID`)
VALUES
	(37,43),
	(38,44),
	(39,45),
	(40,46),
	(41,47),
	(42,49),
	(43,50),
	(44,51),
	(45,52),
	(46,53),
	(47,54),
	(48,55),
	(49,56);

/*!40000 ALTER TABLE `CaseStudyCategoriesPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyCategoriesPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyCategoriesPage_versions`;

CREATE TABLE `CaseStudyCategoriesPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyCategoriesPage_versions` WRITE;
/*!40000 ALTER TABLE `CaseStudyCategoriesPage_versions` DISABLE KEYS */;

INSERT INTO `CaseStudyCategoriesPage_versions` (`ID`, `RecordID`, `Version`, `ImageID`)
VALUES
	(1,37,1,0),
	(2,37,2,43),
	(3,37,3,43),
	(4,38,1,0),
	(5,38,2,44),
	(6,38,3,44),
	(7,39,1,0),
	(8,39,2,45),
	(9,39,3,45),
	(10,40,1,0),
	(11,40,2,46),
	(12,40,3,46),
	(13,41,1,0),
	(14,41,2,47),
	(15,41,3,47),
	(16,42,1,0),
	(17,42,2,48),
	(18,42,3,48),
	(19,42,4,0),
	(20,42,5,49),
	(21,43,1,0),
	(22,43,2,50),
	(23,43,3,50),
	(24,44,1,0),
	(25,44,2,51),
	(26,44,3,51),
	(27,45,1,0),
	(28,45,2,52),
	(29,45,3,52),
	(30,46,1,0),
	(31,46,2,53),
	(32,46,3,53),
	(33,47,1,0),
	(34,47,2,54),
	(35,47,3,54),
	(36,48,1,0),
	(37,48,2,55),
	(38,48,3,55),
	(39,49,1,0),
	(40,49,2,56),
	(41,49,3,56);

/*!40000 ALTER TABLE `CaseStudyCategoriesPage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyHolderPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyHolderPage`;

CREATE TABLE `CaseStudyHolderPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyHolderPage` WRITE;
/*!40000 ALTER TABLE `CaseStudyHolderPage` DISABLE KEYS */;

INSERT INTO `CaseStudyHolderPage` (`ID`, `ImageID`)
VALUES
	(15,2),
	(28,2),
	(22,3),
	(27,3),
	(29,3),
	(16,4),
	(23,4),
	(14,5),
	(24,5),
	(25,5),
	(26,5),
	(12,6),
	(13,6);

/*!40000 ALTER TABLE `CaseStudyHolderPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyHolderPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyHolderPage_Live`;

CREATE TABLE `CaseStudyHolderPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyHolderPage_Live` WRITE;
/*!40000 ALTER TABLE `CaseStudyHolderPage_Live` DISABLE KEYS */;

INSERT INTO `CaseStudyHolderPage_Live` (`ID`, `ImageID`)
VALUES
	(15,2),
	(28,2),
	(22,3),
	(27,3),
	(29,3),
	(16,4),
	(23,4),
	(14,5),
	(24,5),
	(25,5),
	(26,5),
	(12,6),
	(13,6);

/*!40000 ALTER TABLE `CaseStudyHolderPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyHolderPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyHolderPage_versions`;

CREATE TABLE `CaseStudyHolderPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `ImageID` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyHolderPage_versions` WRITE;
/*!40000 ALTER TABLE `CaseStudyHolderPage_versions` DISABLE KEYS */;

INSERT INTO `CaseStudyHolderPage_versions` (`ID`, `RecordID`, `Version`, `ImageID`)
VALUES
	(1,12,1,0),
	(2,12,2,6),
	(3,13,1,0),
	(4,13,2,6),
	(5,14,1,0),
	(6,14,2,5),
	(7,15,1,0),
	(8,15,2,2),
	(9,16,1,0),
	(10,16,2,4),
	(11,22,1,0),
	(12,22,2,3),
	(13,23,1,0),
	(14,23,2,4),
	(15,24,1,0),
	(16,24,2,5),
	(17,25,1,0),
	(18,25,2,5),
	(19,26,1,0),
	(20,26,2,5),
	(21,27,1,0),
	(22,27,2,3),
	(23,28,1,0),
	(24,28,2,2),
	(25,29,1,0),
	(26,29,2,3),
	(27,12,3,6),
	(28,12,4,6),
	(29,13,3,6),
	(30,13,4,6),
	(31,14,3,5),
	(32,14,4,5),
	(33,15,3,2),
	(34,15,4,2),
	(35,16,3,4),
	(36,16,4,4),
	(37,22,3,3),
	(38,22,4,3),
	(39,23,3,4),
	(40,23,4,4),
	(41,24,3,5),
	(42,24,4,5),
	(43,25,3,5),
	(44,25,4,5),
	(45,26,3,5),
	(46,26,4,5),
	(47,27,3,3),
	(48,27,4,3),
	(49,28,3,2),
	(50,28,4,2),
	(51,29,3,3),
	(52,29,4,3);

/*!40000 ALTER TABLE `CaseStudyHolderPage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyPage`;

CREATE TABLE `CaseStudyPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Photo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Logo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `LogoID` int(11) NOT NULL DEFAULT '0',
  `ExcerptPhotoID` int(11) NOT NULL DEFAULT '0',
  `SideBarPhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `PhotoID` (`PhotoID`),
  KEY `LogoID` (`LogoID`),
  KEY `ExcerptPhotoID` (`ExcerptPhotoID`),
  KEY `SideBarPhotoID` (`SideBarPhotoID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyPage` WRITE;
/*!40000 ALTER TABLE `CaseStudyPage` DISABLE KEYS */;

INSERT INTO `CaseStudyPage` (`ID`, `Photo`, `Logo`, `Summary`, `PhotoID`, `LogoID`, `ExcerptPhotoID`, `SideBarPhotoID`)
VALUES
	(17,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,30,29,0),
	(18,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,32,31,0),
	(19,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,34,33,0),
	(20,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,38,37,0),
	(21,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,36,35,0);

/*!40000 ALTER TABLE `CaseStudyPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyPage_CaseStudyCategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyPage_CaseStudyCategories`;

CREATE TABLE `CaseStudyPage_CaseStudyCategories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CaseStudyPageID` int(11) NOT NULL DEFAULT '0',
  `CaseStudyCategoriesID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CaseStudyPageID` (`CaseStudyPageID`),
  KEY `CaseStudyCategoriesID` (`CaseStudyCategoriesID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyPage_CaseStudyCategories` WRITE;
/*!40000 ALTER TABLE `CaseStudyPage_CaseStudyCategories` DISABLE KEYS */;

INSERT INTO `CaseStudyPage_CaseStudyCategories` (`ID`, `CaseStudyPageID`, `CaseStudyCategoriesID`)
VALUES
	(1,16,5);

/*!40000 ALTER TABLE `CaseStudyPage_CaseStudyCategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyPage_CaseStudyCategory
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyPage_CaseStudyCategory`;

CREATE TABLE `CaseStudyPage_CaseStudyCategory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CaseStudyPageID` int(11) NOT NULL DEFAULT '0',
  `CaseStudyCategoriesID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CaseStudyPageID` (`CaseStudyPageID`),
  KEY `CaseStudyCategoriesID` (`CaseStudyCategoriesID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyPage_CaseStudyCategory` WRITE;
/*!40000 ALTER TABLE `CaseStudyPage_CaseStudyCategory` DISABLE KEYS */;

INSERT INTO `CaseStudyPage_CaseStudyCategory` (`ID`, `CaseStudyPageID`, `CaseStudyCategoriesID`)
VALUES
	(1,17,5),
	(2,17,6),
	(3,18,5),
	(4,18,6),
	(5,19,5),
	(6,19,6),
	(7,21,5),
	(8,21,6),
	(9,20,5),
	(10,20,6);

/*!40000 ALTER TABLE `CaseStudyPage_CaseStudyCategory` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyPage_Live`;

CREATE TABLE `CaseStudyPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Photo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Logo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `LogoID` int(11) NOT NULL DEFAULT '0',
  `ExcerptPhotoID` int(11) NOT NULL DEFAULT '0',
  `SideBarPhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `PhotoID` (`PhotoID`),
  KEY `LogoID` (`LogoID`),
  KEY `ExcerptPhotoID` (`ExcerptPhotoID`),
  KEY `SideBarPhotoID` (`SideBarPhotoID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyPage_Live` WRITE;
/*!40000 ALTER TABLE `CaseStudyPage_Live` DISABLE KEYS */;

INSERT INTO `CaseStudyPage_Live` (`ID`, `Photo`, `Logo`, `Summary`, `PhotoID`, `LogoID`, `ExcerptPhotoID`, `SideBarPhotoID`)
VALUES
	(17,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,30,29,0),
	(18,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,32,31,0),
	(19,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,34,33,0),
	(20,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,38,37,0),
	(21,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,36,35,0);

/*!40000 ALTER TABLE `CaseStudyPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table CaseStudyPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `CaseStudyPage_versions`;

CREATE TABLE `CaseStudyPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Photo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Logo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `LogoID` int(11) NOT NULL DEFAULT '0',
  `ExcerptPhotoID` int(11) NOT NULL DEFAULT '0',
  `SideBarPhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `PhotoID` (`PhotoID`),
  KEY `LogoID` (`LogoID`),
  KEY `ExcerptPhotoID` (`ExcerptPhotoID`),
  KEY `SideBarPhotoID` (`SideBarPhotoID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `CaseStudyPage_versions` WRITE;
/*!40000 ALTER TABLE `CaseStudyPage_versions` DISABLE KEYS */;

INSERT INTO `CaseStudyPage_versions` (`ID`, `RecordID`, `Version`, `Photo`, `Logo`, `Summary`, `PhotoID`, `LogoID`, `ExcerptPhotoID`, `SideBarPhotoID`)
VALUES
	(1,17,1,NULL,NULL,NULL,0,0,0,0),
	(2,17,2,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(3,18,1,NULL,NULL,NULL,0,0,0,0),
	(4,18,2,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(5,19,1,NULL,NULL,NULL,0,0,0,0),
	(6,19,2,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(7,20,1,NULL,NULL,NULL,0,0,0,0),
	(8,20,2,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,0,0),
	(9,21,1,NULL,NULL,NULL,0,0,0,0),
	(10,21,2,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,0,0),
	(11,17,3,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(12,17,4,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(13,18,3,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(14,18,4,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(15,19,3,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(16,19,4,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(17,20,3,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,0,0),
	(18,20,4,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,0,0),
	(19,21,3,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,0,0),
	(20,21,4,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,0,0),
	(21,17,5,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(22,17,6,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(23,18,5,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(24,18,6,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(25,17,7,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(26,17,8,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','At enim hic etiam dolore. Hic ambiguo ludimur.',0,0,0,0),
	(27,18,7,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(28,18,8,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,0,0),
	(29,21,5,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,0,0),
	(30,21,6,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,0,0),
	(31,20,5,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,0,0),
	(32,20,6,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,0,0),
	(33,19,5,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(34,19,6,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(35,16,5,NULL,NULL,NULL,0,0,0,0),
	(36,17,9,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,0,0,0),
	(37,17,10,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,0,29,0),
	(38,17,11,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,30,29,0),
	(39,18,9,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,0,31,0),
	(40,18,10,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','Pugnant Stoici cum Peripateticis. Fortemne possumus',0,32,31,0),
	(41,18,11,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,32,31,0),
	(42,19,7,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,0,0),
	(43,19,8,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,0,33,0),
	(44,19,9,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','Audeo dicere, inquit. Restatis igitur vos; Quod',0,34,33,0),
	(45,19,10,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,34,33,0),
	(46,21,7,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,0,35,0),
	(47,21,8,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','Age, inquies, ista parva sunt. Nunc',0,36,35,0),
	(48,21,9,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,36,35,0),
	(49,21,10,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,36,35,0),
	(50,20,7,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,0,37,0),
	(51,20,8,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','Bestiarum vero nullum iudicium puto. Quid',0,38,37,0),
	(52,20,9,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,38,37,0),
	(53,17,12,'Haec dicuntur inconstantissime. Deprehensus omnem poenam','Confecta res esset.','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,30,29,0),
	(54,18,12,'Erat enim res aperta. Certe, nisi voluptatem tanti','Istam voluptatem, inquit, Epicurus','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,32,31,0),
	(55,19,11,'Negat esse eam, inquit, propter','Simus igitur contenti his. Duo Reges: constructio','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,34,33,0),
	(56,20,10,'Praeteritis, inquit, gaudeo. Praeclare hoc quidem.','Nunc vides,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,38,37,0),
	(57,21,11,'Certe non potest. Equidem e','At hoc in eo M. Que Manilium,','<h4>The Objective</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>\n<h4>The Challenge</h4>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum</p>',0,36,35,0);

/*!40000 ALTER TABLE `CaseStudyPage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Email_BounceRecord
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Email_BounceRecord`;

CREATE TABLE `Email_BounceRecord` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Email_BounceRecord') CHARACTER SET utf8 DEFAULT 'Email_BounceRecord',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `BounceEmail` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BounceTime` datetime DEFAULT NULL,
  `BounceMessage` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table ErrorPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ErrorPage`;

CREATE TABLE `ErrorPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `ErrorPage` WRITE;
/*!40000 ALTER TABLE `ErrorPage` DISABLE KEYS */;

INSERT INTO `ErrorPage` (`ID`, `ErrorCode`)
VALUES
	(4,404),
	(5,500),
	(33,404),
	(34,500);

/*!40000 ALTER TABLE `ErrorPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ErrorPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ErrorPage_Live`;

CREATE TABLE `ErrorPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `ErrorPage_Live` WRITE;
/*!40000 ALTER TABLE `ErrorPage_Live` DISABLE KEYS */;

INSERT INTO `ErrorPage_Live` (`ID`, `ErrorCode`)
VALUES
	(4,404),
	(5,500),
	(33,404),
	(34,500);

/*!40000 ALTER TABLE `ErrorPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ErrorPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ErrorPage_versions`;

CREATE TABLE `ErrorPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `ErrorPage_versions` WRITE;
/*!40000 ALTER TABLE `ErrorPage_versions` DISABLE KEYS */;

INSERT INTO `ErrorPage_versions` (`ID`, `RecordID`, `Version`, `ErrorCode`)
VALUES
	(3,33,1,404),
	(4,34,1,500);

/*!40000 ALTER TABLE `ErrorPage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table File
# ------------------------------------------------------------

DROP TABLE IF EXISTS `File`;

CREATE TABLE `File` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('File','Folder','Image','Image_Cached') CHARACTER SET utf8 DEFAULT 'File',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Filename` mediumtext CHARACTER SET utf8,
  `Content` mediumtext CHARACTER SET utf8,
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `OwnerID` (`OwnerID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `File` WRITE;
/*!40000 ALTER TABLE `File` DISABLE KEYS */;

INSERT INTO `File` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Filename`, `Content`, `ShowInSearch`, `ParentID`, `OwnerID`)
VALUES
	(1,'Folder','2013-07-03 19:11:04','2013-07-03 19:11:04','silversmith-samples','silversmith-samples','assets/silversmith-samples/',NULL,1,0,0),
	(2,'Image','2013-07-03 19:11:04','2013-07-03 19:11:04','image1.gif','image1.gif','assets/silversmith-samples/image1.gif',NULL,1,1,0),
	(4,'Image','2013-07-03 19:11:04','2013-07-03 19:11:04','image3.gif','image3.gif','assets/silversmith-samples/image3.gif',NULL,1,1,0),
	(5,'Image','2013-07-03 19:11:04','2013-07-03 19:11:04','image4.gif','image4.gif','assets/silversmith-samples/image4.gif',NULL,1,1,0),
	(6,'Image','2013-07-03 19:11:04','2013-07-03 19:11:04','image5.gif','image5.gif','assets/silversmith-samples/image5.gif',NULL,1,1,0),
	(7,'File','2013-07-03 19:11:04','2013-07-03 19:11:04','pdf1.pdf','pdf1.pdf','assets/silversmith-samples/pdf1.pdf',NULL,1,1,0),
	(8,'File','2013-07-03 19:11:04','2013-07-03 19:11:04','pdf2.pdf','pdf2.pdf','assets/silversmith-samples/pdf2.pdf',NULL,1,1,0),
	(9,'File','2013-07-03 19:11:04','2013-07-03 19:11:04','pdf3.pdf','pdf3.pdf','assets/silversmith-samples/pdf3.pdf',NULL,1,1,0),
	(10,'File','2013-07-03 19:11:04','2013-07-03 19:11:04','pdf4.pdf','pdf4.pdf','assets/silversmith-samples/pdf4.pdf',NULL,1,1,0),
	(11,'File','2013-07-03 19:11:04','2013-07-03 19:11:04','pdf5.pdf','pdf5.pdf','assets/silversmith-samples/pdf5.pdf',NULL,1,1,0),
	(12,'Folder','2013-07-06 15:36:14','2013-07-06 15:36:14','Uploads','Uploads','assets/Uploads/',NULL,1,0,1),
	(13,'Image','2013-07-06 15:36:14','2013-07-06 15:36:14','Facebook.png','Facebook','assets/Uploads/Facebook.png',NULL,1,12,1),
	(14,'Image','2013-07-06 15:37:50','2013-07-06 15:37:50','LinkedIn.png','LinkedIn','assets/Uploads/LinkedIn.png',NULL,1,12,1),
	(15,'Image','2013-07-06 15:47:54','2013-07-06 15:47:54','email.png','email','assets/Uploads/email.png',NULL,1,12,1),
	(16,'Image','2013-07-06 17:35:05','2013-07-06 17:35:05','cs1.png','cs1','assets/Uploads/cs1.png',NULL,1,12,1),
	(17,'Image','2013-07-06 17:35:55','2013-07-06 17:35:55','sc2.png','sc2','assets/Uploads/sc2.png',NULL,1,12,1),
	(18,'Image','2013-07-06 17:37:10','2013-07-06 17:37:10','cs3.png','cs3','assets/Uploads/cs3.png',NULL,1,12,1),
	(19,'Image','2013-07-06 17:38:18','2013-07-06 17:38:18','sc4.png','sc4','assets/Uploads/sc4.png',NULL,1,12,1),
	(20,'Image','2013-07-06 17:39:03','2013-07-06 17:39:03','sc5.png','sc5','assets/Uploads/sc5.png',NULL,1,12,1),
	(21,'Image','2013-07-06 17:40:09','2013-07-06 17:40:09','sc8.png','sc8','assets/Uploads/sc8.png',NULL,1,12,1),
	(22,'Image','2013-07-06 17:41:04','2013-07-06 17:41:04','sc7.png','sc7','assets/Uploads/sc7.png',NULL,1,12,1),
	(23,'Image','2013-07-06 17:41:50','2013-07-06 17:41:50','sc3.png','sc3','assets/Uploads/sc3.png',NULL,1,12,1),
	(24,'Image','2013-07-06 17:42:26','2013-07-06 17:42:26','sc9.png','sc9','assets/Uploads/sc9.png',NULL,1,12,1),
	(25,'Image','2013-07-06 17:43:02','2013-07-06 17:43:02','sc10.png','sc10','assets/Uploads/sc10.png',NULL,1,12,1),
	(26,'Image','2013-07-06 17:43:38','2013-07-06 17:43:38','sc11.png','sc11','assets/Uploads/sc11.png',NULL,1,12,1),
	(27,'Image','2013-07-06 17:44:13','2013-07-06 17:44:13','sc12.png','sc12','assets/Uploads/sc12.png',NULL,1,12,1),
	(28,'Image','2013-07-06 17:44:39','2013-07-06 17:44:39','sc13.png','sc13','assets/Uploads/sc13.png',NULL,1,12,1),
	(29,'Image','2013-07-06 18:48:23','2013-07-06 18:48:23','bp1.jpg','bp1','assets/Uploads/bp1.jpg',NULL,1,12,1),
	(30,'Image','2013-07-06 18:48:30','2013-07-06 18:48:30','bpLogo.png','bpLogo','assets/Uploads/bpLogo.png',NULL,1,12,1),
	(31,'Image','2013-07-06 18:49:47','2013-07-06 18:49:47','thames.jpg','thames','assets/Uploads/thames.jpg',NULL,1,12,1),
	(32,'Image','2013-07-06 18:49:52','2013-07-06 18:49:52','thamesLogo.png','thamesLogo','assets/Uploads/thamesLogo.png',NULL,1,12,1),
	(33,'Image','2013-07-06 18:51:04','2013-07-06 18:51:04','nztransport.jpg','nztransport','assets/Uploads/nztransport.jpg',NULL,1,12,1),
	(34,'Image','2013-07-06 18:51:15','2013-07-06 18:51:15','nzTransportLogo.png','nzTransportLogo','assets/Uploads/nzTransportLogo.png',NULL,1,12,1),
	(35,'Image','2013-07-06 18:52:18','2013-07-06 18:52:18','energy.jpg','energy','assets/Uploads/energy.jpg',NULL,1,12,1),
	(36,'Image','2013-07-06 18:52:25','2013-07-06 18:52:25','mightRiverpowerLogo.png','mightRiverpowerLogo','assets/Uploads/mightRiverpowerLogo.png',NULL,1,12,1),
	(37,'Image','2013-07-06 18:53:37','2013-07-06 18:53:37','landcorp.jpg','landcorp','assets/Uploads/landcorp.jpg',NULL,1,12,1),
	(38,'Image','2013-07-06 18:53:44','2013-07-06 18:53:44','landcorpLogo.png','landcorpLogo','assets/Uploads/landcorpLogo.png',NULL,1,12,1),
	(39,'Image','2013-07-06 19:14:54','2013-07-06 19:14:54','hero.jpg','hero','assets/Uploads/hero.jpg',NULL,1,12,1),
	(40,'Image','2013-07-07 16:57:16','2013-07-07 16:57:16','about1.png','about1','assets/Uploads/about1.png',NULL,1,12,1),
	(41,'Image','2013-07-07 16:59:57','2013-07-07 16:59:57','about2.png','about2','assets/Uploads/about2.png',NULL,1,12,1),
	(42,'Image','2013-07-07 17:00:47','2013-07-07 17:00:47','about3.png','about3','assets/Uploads/about3.png',NULL,1,12,1),
	(43,'Image','2013-07-07 22:03:18','2013-07-07 22:03:18','cs2.png','cs2','assets/Uploads/cs2.png',NULL,1,12,1),
	(44,'Image','2013-07-07 22:04:21','2013-07-07 22:04:21','sc6.png','sc6','assets/Uploads/sc6.png',NULL,1,12,1),
	(45,'Image','2013-07-07 22:06:55','2013-07-07 22:06:55','cs4.png','cs4','assets/Uploads/cs4.png',NULL,1,12,1),
	(46,'Image','2013-07-07 22:07:41','2013-07-07 22:07:41','sc14.png','sc14','assets/Uploads/sc14.png',NULL,1,12,1),
	(47,'Image','2013-07-07 22:08:11','2013-07-07 22:08:11','sc15.png','sc15','assets/Uploads/sc15.png',NULL,1,12,1),
	(49,'Image','2013-07-07 22:12:05','2013-07-07 22:12:05','lg.jpg','lg','assets/Uploads/lg.jpg',NULL,1,12,1),
	(50,'Image','2013-07-07 22:13:33','2013-07-07 22:13:33','sc16.png','sc16','assets/Uploads/sc16.png',NULL,1,12,1),
	(51,'Image','2013-07-07 22:14:07','2013-07-07 22:14:07','sc17.png','sc17','assets/Uploads/sc17.png',NULL,1,12,1),
	(52,'Image','2013-07-07 22:14:52','2013-07-07 22:14:52','sc18.png','sc18','assets/Uploads/sc18.png',NULL,1,12,1),
	(53,'Image','2013-07-07 22:15:15','2013-07-07 22:15:15','sc19.png','sc19','assets/Uploads/sc19.png',NULL,1,12,1),
	(54,'Image','2013-07-07 22:16:10','2013-07-07 22:16:10','sc20.png','sc20','assets/Uploads/sc20.png',NULL,1,12,1),
	(55,'Image','2013-07-07 22:16:39','2013-07-07 22:16:39','sc21.png','sc21','assets/Uploads/sc21.png',NULL,1,12,1),
	(56,'Image','2013-07-07 22:17:43','2013-07-07 22:17:43','sc22.png','sc22','assets/Uploads/sc22.png',NULL,1,12,1);

/*!40000 ALTER TABLE `File` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Group`;

CREATE TABLE `Group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Group') CHARACTER SET utf8 DEFAULT 'Group',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Description` mediumtext CHARACTER SET utf8,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HtmlEditorConfig` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `Group` WRITE;
/*!40000 ALTER TABLE `Group` DISABLE KEYS */;

INSERT INTO `Group` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Description`, `Code`, `Locked`, `Sort`, `HtmlEditorConfig`, `ParentID`)
VALUES
	(1,'Group','2013-07-03 18:17:46','2013-07-03 18:17:46','Content Authors',NULL,'content-authors',0,1,NULL,0),
	(2,'Group','2013-07-03 18:17:46','2013-07-03 18:17:46','Administrators',NULL,'administrators',0,0,NULL,0);

/*!40000 ALTER TABLE `Group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Group_Members
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Group_Members`;

CREATE TABLE `Group_Members` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `MemberID` (`MemberID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `Group_Members` WRITE;
/*!40000 ALTER TABLE `Group_Members` DISABLE KEYS */;

INSERT INTO `Group_Members` (`ID`, `GroupID`, `MemberID`)
VALUES
	(1,2,1);

/*!40000 ALTER TABLE `Group_Members` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Group_Roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Group_Roles`;

CREATE TABLE `Group_Roles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `PermissionRoleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `PermissionRoleID` (`PermissionRoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table HomePage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `HomePage`;

CREATE TABLE `HomePage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HeroCaption` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `HeroImageID` int(11) NOT NULL DEFAULT '0',
  `CaseStudyHolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `HeroImageID` (`HeroImageID`),
  KEY `CaseStudyHolderID` (`CaseStudyHolderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `HomePage` WRITE;
/*!40000 ALTER TABLE `HomePage` DISABLE KEYS */;

INSERT INTO `HomePage` (`ID`, `HeroCaption`, `HeroImageID`, `CaseStudyHolderID`)
VALUES
	(6,'Do you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it?',39,0);

/*!40000 ALTER TABLE `HomePage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table HomePage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `HomePage_Live`;

CREATE TABLE `HomePage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HeroCaption` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `HeroImageID` int(11) NOT NULL DEFAULT '0',
  `CaseStudyHolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `HeroImageID` (`HeroImageID`),
  KEY `CaseStudyHolderID` (`CaseStudyHolderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `HomePage_Live` WRITE;
/*!40000 ALTER TABLE `HomePage_Live` DISABLE KEYS */;

INSERT INTO `HomePage_Live` (`ID`, `HeroCaption`, `HeroImageID`, `CaseStudyHolderID`)
VALUES
	(6,'Do you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it?',39,0);

/*!40000 ALTER TABLE `HomePage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table HomePage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `HomePage_versions`;

CREATE TABLE `HomePage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `HeroCaption` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `HeroImageID` int(11) NOT NULL DEFAULT '0',
  `CaseStudyHolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `HeroImageID` (`HeroImageID`),
  KEY `CaseStudyHolderID` (`CaseStudyHolderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `HomePage_versions` WRITE;
/*!40000 ALTER TABLE `HomePage_versions` DISABLE KEYS */;

INSERT INTO `HomePage_versions` (`ID`, `RecordID`, `Version`, `HeroCaption`, `HeroImageID`, `CaseStudyHolderID`)
VALUES
	(1,6,1,NULL,0,0),
	(2,6,2,'Explanetur igitur. Eam stabilem appellas. Nescio quo',3,0),
	(3,6,3,'Explanetur igitur. Eam stabilem appellas. Nescio quo',0,0),
	(4,6,4,'Explanetur igitur. Eam stabilem appellas. Nescio quo',39,0),
	(5,6,5,'Do you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it?',39,0),
	(6,6,6,'Do you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it?',39,0),
	(7,6,7,'Do you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it?',39,0);

/*!40000 ALTER TABLE `HomePage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LoginAttempt
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LoginAttempt`;

CREATE TABLE `LoginAttempt` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('LoginAttempt') CHARACTER SET utf8 DEFAULT 'LoginAttempt',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Status` enum('Success','Failure') CHARACTER SET utf8 DEFAULT 'Success',
  `IP` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table Member
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Member`;

CREATE TABLE `Member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Member') CHARACTER SET utf8 DEFAULT 'Member',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `FirstName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Surname` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Email` varchar(256) CHARACTER SET utf8 DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `RememberLoginToken` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `NumVisit` int(11) NOT NULL DEFAULT '0',
  `LastVisited` datetime DEFAULT NULL,
  `Bounced` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AutoLoginHash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `AutoLoginExpired` datetime DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordExpiry` date DEFAULT NULL,
  `LockedOutUntil` datetime DEFAULT NULL,
  `Locale` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `FailedLoginCount` int(11) NOT NULL DEFAULT '0',
  `DateFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `TimeFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Email` (`Email`(255)),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `Member` WRITE;
/*!40000 ALTER TABLE `Member` DISABLE KEYS */;

INSERT INTO `Member` (`ID`, `ClassName`, `Created`, `LastEdited`, `FirstName`, `Surname`, `Email`, `Password`, `RememberLoginToken`, `NumVisit`, `LastVisited`, `Bounced`, `AutoLoginHash`, `AutoLoginExpired`, `PasswordEncryption`, `Salt`, `PasswordExpiry`, `LockedOutUntil`, `Locale`, `FailedLoginCount`, `DateFormat`, `TimeFormat`)
VALUES
	(1,'Member','2013-07-03 18:17:46','2013-07-06 15:34:05','Default Admin',NULL,NULL,NULL,NULL,3,'2013-07-07 22:42:15',0,NULL,NULL,NULL,NULL,NULL,NULL,'en_GB',0,NULL,NULL);

/*!40000 ALTER TABLE `Member` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table MemberPassword
# ------------------------------------------------------------

DROP TABLE IF EXISTS `MemberPassword`;

CREATE TABLE `MemberPassword` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('MemberPassword') CHARACTER SET utf8 DEFAULT 'MemberPassword',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table Permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Permission`;

CREATE TABLE `Permission` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Permission') CHARACTER SET utf8 DEFAULT 'Permission',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Arg` int(11) NOT NULL DEFAULT '0',
  `Type` int(11) NOT NULL DEFAULT '1',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `Code` (`Code`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `Permission` WRITE;
/*!40000 ALTER TABLE `Permission` DISABLE KEYS */;

INSERT INTO `Permission` (`ID`, `ClassName`, `Created`, `LastEdited`, `Code`, `Arg`, `Type`, `GroupID`)
VALUES
	(1,'Permission','2013-07-03 18:17:46','2013-07-03 18:17:46','CMS_ACCESS_CMSMain',0,1,1),
	(2,'Permission','2013-07-03 18:17:46','2013-07-03 18:17:46','CMS_ACCESS_AssetAdmin',0,1,1),
	(3,'Permission','2013-07-03 18:17:46','2013-07-03 18:17:46','CMS_ACCESS_ReportAdmin',0,1,1),
	(4,'Permission','2013-07-03 18:17:46','2013-07-03 18:17:46','SITETREE_REORGANISE',0,1,1),
	(5,'Permission','2013-07-03 18:17:46','2013-07-03 18:17:46','ADMIN',0,1,2);

/*!40000 ALTER TABLE `Permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table PermissionRole
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionRole`;

CREATE TABLE `PermissionRole` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PermissionRole') CHARACTER SET utf8 DEFAULT 'PermissionRole',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnlyAdminCanApply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table PermissionRoleCode
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PermissionRoleCode`;

CREATE TABLE `PermissionRoleCode` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PermissionRoleCode') CHARACTER SET utf8 DEFAULT 'PermissionRoleCode',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `RoleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RoleID` (`RoleID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table RedirectorPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `RedirectorPage`;

CREATE TABLE `RedirectorPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table RedirectorPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `RedirectorPage_Live`;

CREATE TABLE `RedirectorPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table RedirectorPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `RedirectorPage_versions`;

CREATE TABLE `RedirectorPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SellingPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SellingPage`;

CREATE TABLE `SellingPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Summary` mediumtext CHARACTER SET utf8,
  `BannerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `BannerID` (`BannerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SellingPage` WRITE;
/*!40000 ALTER TABLE `SellingPage` DISABLE KEYS */;

INSERT INTO `SellingPage` (`ID`, `Summary`, `BannerID`)
VALUES
	(8,'<p>CS-VUE is a cloud software service which helps users to track, manage and report upon environmental compliance obligations, undertake environmental audits and manage environmental incidents such as a spills and complaints. </p>',40),
	(9,'<p>CS-VUE makes environmental compliance, incident management and auditing easy! Benefits include avoidance of prosecution, governance reporting transparency, improved stakeholder relationships, improved regulatory relationships</p>',41),
	(10,'<p>We are here to help! Get in contact to arrange a product demonstration and talk about how we can make your environmental compliance and reporting obligations easier to manage.</p>',42);

/*!40000 ALTER TABLE `SellingPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SellingPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SellingPage_Live`;

CREATE TABLE `SellingPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Summary` mediumtext CHARACTER SET utf8,
  `BannerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `BannerID` (`BannerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SellingPage_Live` WRITE;
/*!40000 ALTER TABLE `SellingPage_Live` DISABLE KEYS */;

INSERT INTO `SellingPage_Live` (`ID`, `Summary`, `BannerID`)
VALUES
	(8,'<p>CS-VUE is a cloud software service which helps users to track, manage and report upon environmental compliance obligations, undertake environmental audits and manage environmental incidents such as a spills and complaints. </p>',40),
	(9,'<p>CS-VUE makes environmental compliance, incident management and auditing easy! Benefits include avoidance of prosecution, governance reporting transparency, improved stakeholder relationships, improved regulatory relationships</p>',41),
	(10,'<p>We are here to help! Get in contact to arrange a product demonstration and talk about how we can make your environmental compliance and reporting obligations easier to manage.</p>',42);

/*!40000 ALTER TABLE `SellingPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SellingPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SellingPage_versions`;

CREATE TABLE `SellingPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Summary` mediumtext CHARACTER SET utf8,
  `BannerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `BannerID` (`BannerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SellingPage_versions` WRITE;
/*!40000 ALTER TABLE `SellingPage_versions` DISABLE KEYS */;

INSERT INTO `SellingPage_versions` (`ID`, `RecordID`, `Version`, `Summary`, `BannerID`)
VALUES
	(1,8,4,NULL,0),
	(2,8,5,NULL,40),
	(3,8,6,'<p>CS-VUE is a cloud software service which helps users to track, manage and report upon environmental compliance obligations, undertake environmental audits and manage environmental incidents such as a spills and complaints. </p>',40),
	(4,9,4,NULL,0),
	(5,9,5,NULL,41),
	(6,9,6,'<p>CS-VUE makes environmental compliance, incident management and auditing easy! Benefits include avoidance of prosecution, governance reporting transparency, improved stakeholder relationships, improved regulatory relationships</p>',41),
	(7,10,4,NULL,0),
	(8,10,5,NULL,42),
	(9,10,6,'<p>We are here to help! Get in contact to arrange a product demonstration and talk about how we can make your environmental compliance and reporting obligations easier to manage.</p>',42);

/*!40000 ALTER TABLE `SellingPage_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SiteConfig
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteConfig`;

CREATE TABLE `SiteConfig` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('SiteConfig') CHARACTER SET utf8 DEFAULT 'SiteConfig',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Tagline` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Theme` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'Anyone',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `CanCreateTopLevelType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `Address` mediumtext CHARACTER SET utf8,
  `Phone` mediumtext CHARACTER SET utf8,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `copyright` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SiteConfig` WRITE;
/*!40000 ALTER TABLE `SiteConfig` DISABLE KEYS */;

INSERT INTO `SiteConfig` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Tagline`, `Theme`, `CanViewType`, `CanEditType`, `CanCreateTopLevelType`, `Address`, `Phone`, `email`, `copyright`)
VALUES
	(1,'SiteConfig','2013-07-03 18:17:46','2013-07-07 18:34:44','csvue','Online Environment Compliance  |  Incident Management  |  Audit Systems ',NULL,'Anyone','LoggedInUsers','LoggedInUsers','<p>Level 1, Barrington Building</p>\n<p>10-12 Customs Street East Britomart</p>\n<p>Auckland CBD</p>\n<p> </p>\n<p>PO Box 911 491</p>\n<p>Victoria Street West</p>\n<p>Auckland 1142</p>\n<p>Auckland, New Zealand</p>','<p>Call Auckland, Nz (GMT+12)</p>\n<p>+64 9 984 7732</p>','contact@csvue.com','Resource Management Technology Group Limited'),
	(2,'SiteConfig','2013-07-03 21:33:02','2013-07-03 21:33:02','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(3,'SiteConfig','2013-07-03 21:33:03','2013-07-03 21:33:03','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(4,'SiteConfig','2013-07-03 21:33:06','2013-07-03 21:33:06','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(5,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(6,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(7,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(8,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(9,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(10,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(11,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(12,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(13,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(14,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(15,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(16,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(17,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(18,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(19,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(20,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(21,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(22,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(23,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(24,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(25,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(26,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(27,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(28,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(29,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(30,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(31,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(32,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(33,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(34,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(35,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(36,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(37,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(38,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(39,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(40,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(41,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(42,'SiteConfig','2013-07-03 21:33:07','2013-07-03 21:33:07','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(43,'SiteConfig','2013-07-03 21:33:08','2013-07-03 21:33:08','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(44,'SiteConfig','2013-07-03 21:33:08','2013-07-03 21:33:08','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(45,'SiteConfig','2013-07-03 21:33:08','2013-07-03 21:33:08','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL),
	(46,'SiteConfig','2013-07-03 21:33:08','2013-07-03 21:33:08','Your Site Name','your tagline here',NULL,'Anyone','LoggedInUsers','LoggedInUsers',NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `SiteConfig` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SiteConfig_CreateTopLevelGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteConfig_CreateTopLevelGroups`;

CREATE TABLE `SiteConfig_CreateTopLevelGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteConfig_EditorGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteConfig_EditorGroups`;

CREATE TABLE `SiteConfig_EditorGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteConfig_ViewerGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteConfig_ViewerGroups`;

CREATE TABLE `SiteConfig_ViewerGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteTree
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree`;

CREATE TABLE `SiteTree` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Page','AboutPage','CaseStudyPage','ContactPage','HomePage','ErrorPage','BlogEntry','BlogHolder','SellingPage','CaseStudyCategoriesPage','SiteTree','BlogTree','RedirectorPage','VirtualPage') CHARACTER SET utf8 DEFAULT 'Page',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SiteTree` WRITE;
/*!40000 ALTER TABLE `SiteTree` DISABLE KEYS */;

INSERT INTO `SiteTree` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `Version`, `ParentID`)
VALUES
	(6,'HomePage','2013-07-03 21:09:07','2013-07-07 22:31:17','home','Home',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,NULL,'Inherit','Inherit',7,0),
	(7,'AboutPage','2013-07-03 21:09:09','2013-07-03 21:09:09','about','About',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. <a href=\"http://loripsum.net/\" target=\"_blank\">Ea possunt paria non esse.</a> Duo Reges: constructio interrete. Sequitur disserendi ratio cognitioque naturae; </p>\n\n<p>Quis enim redargueret? Rationis enim perfectio est virtus; Si id dicis, vicimus. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Refert tamen, quo modo.</a> Ut pulsi recurrant? Itaque his sapiens semper vacabit. Duarum enim vitarum nobis erunt instituta capienda. Utram tandem linguam nescio? </p>\n\n<p>Bonum valitudo: miser morbus. Nihil sane. Tollenda est atque extrahenda radicitus. <a href=\"http://loripsum.net/\" target=\"_blank\">Polycratem Samium felicem appellabant.</a> Deinde dolorem quem maximum? Satis est ad hoc responsum. </p>\n\n<p>Si longus, levis dictata sunt. <a href=\"http://loripsum.net/\" target=\"_blank\">Eam stabilem appellas.</a> Pauca mutat vel plura sane; Stoici scilicet. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',1,0),
	(8,'SellingPage','2013-07-03 21:09:34','2013-07-07 16:57:19','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a></p>\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas.</p>\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum?</p>\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí?</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',6,7),
	(9,'SellingPage','2013-07-03 21:09:36','2013-07-07 17:00:01','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete.</p>\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius.</p>\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit?</p>\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',6,7),
	(10,'SellingPage','2013-07-03 21:09:37','2013-07-07 17:00:49','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis.</p>\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem.</p>\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita.</p>\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum.</p>\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat;</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',6,7),
	(11,'Page','2013-07-03 21:09:38','2013-07-07 22:32:36','case-studies','Case Studies',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',10,0),
	(17,'CaseStudyPage','2013-07-03 21:09:47','2013-07-07 22:33:45','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',12,41),
	(18,'CaseStudyPage','2013-07-03 21:09:52','2013-07-07 22:33:54','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio.</p>\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a></p>\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit.</p>\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio?</p>\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto;</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',12,41),
	(19,'CaseStudyPage','2013-07-03 21:09:57','2013-07-07 22:34:05','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni?</p>\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a></p>\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis.</p>\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem?</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto.</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11,41),
	(20,'CaseStudyPage','2013-07-03 21:10:02','2013-07-07 22:34:17','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete.</p>\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis;</p>\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas.</p>\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane.</p>\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa.</p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',10,41),
	(21,'CaseStudyPage','2013-07-03 21:10:08','2013-07-07 22:34:27','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio?</p>\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur?</p>\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a></p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn.</p>\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est?</p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11,41),
	(30,'ContactPage','2013-07-03 21:10:25','2013-07-03 21:10:25','contact-us','Contact Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proclivi currit oratio. Equidem e Cn. Duo Reges: constructio interrete. </p>\n\n<p>Sed haec in pueris; Ostendit pedes et pectus. Quid enim possumus hoc agere divinius? Quid iudicant sensus? Faceres tu quidem, Torquate, haec omnia; Eaedem res maneant alio modo. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Non est igitur voluptas bonum. Bonum patria: miserum exilium. Non est igitur voluptas bonum. Eadem fortitudinis ratio reperietur. </p>\n\n<p>Velut ego nunc moveor. Negare non possum. Peccata paria. Ut id aliis narrare gestiant? </p>\n\n<p>Dici enim nihil potest verius. Qui est in parvis malis. Tollenda est atque extrahenda radicitus. Illi enim inter se dissentiunt. </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',1,0),
	(31,'Page','2013-07-03 21:27:57','2013-07-03 21:28:15','resellers','Resellers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',3,0),
	(32,'Page','2013-07-03 21:29:48','2013-07-03 21:30:25','refer-us','Refer Us',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',3,0),
	(33,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','page-not-found','Page not found',NULL,'<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p>\n<p>Please check the spelling of the URL you were trying to access and try again.</p>',NULL,NULL,NULL,NULL,0,0,9,0,0,NULL,'Inherit','Inherit',1,0),
	(34,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','server-error','Server error',NULL,'<p>Sorry, there was a problem handling your request.</p>',NULL,NULL,NULL,NULL,0,0,10,0,0,NULL,'Inherit','Inherit',1,0),
	(35,'BlogHolder','2013-07-06 17:25:00','2013-07-06 17:25:00','blog','Blog',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',1,0),
	(36,'BlogEntry','2013-07-06 17:25:00','2013-07-06 17:25:00','sample-blog-entry','SilverStripe blog module successfully installed',NULL,'Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog (such as the widgets displayed in the sidebar) in [url=admin]the CMS[/url].',NULL,NULL,NULL,NULL,0,1,0,0,0,NULL,'Inherit','Inherit',1,35),
	(37,'CaseStudyCategoriesPage','2013-07-07 21:56:13','2013-07-07 22:03:30','transport','Transport',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',3,11),
	(38,'CaseStudyCategoriesPage','2013-07-07 22:03:42','2013-07-07 22:04:36','agriculture','Agriculture',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',3,11),
	(39,'CaseStudyCategoriesPage','2013-07-07 22:04:47','2013-07-07 22:07:00','mining','Mining',NULL,NULL,NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',3,11),
	(40,'CaseStudyCategoriesPage','2013-07-07 22:07:09','2013-07-07 22:07:43','infrastructure','Infrastructure',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',3,11),
	(41,'CaseStudyCategoriesPage','2013-07-07 22:07:52','2013-07-07 22:08:14','oil-and-gas','Oil & Gas',NULL,NULL,NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',3,11),
	(42,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:12:14','local-government','Local Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',5,11),
	(43,'CaseStudyCategoriesPage','2013-07-07 22:12:24','2013-07-07 22:13:36','manufacture-and-process','Manufacture & Process',NULL,NULL,NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',3,11),
	(44,'CaseStudyCategoriesPage','2013-07-07 22:13:44','2013-07-07 22:14:10','central-government','Central Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',3,11),
	(45,'CaseStudyCategoriesPage','2013-07-07 22:14:33','2013-07-07 22:14:54','defence','Defence',NULL,NULL,NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',3,11),
	(46,'CaseStudyCategoriesPage','2013-07-07 22:15:00','2013-07-07 22:15:17','services','Services',NULL,NULL,NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',3,11),
	(47,'CaseStudyCategoriesPage','2013-07-07 22:15:29','2013-07-07 22:16:14','energy','Energy',NULL,NULL,NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',3,11),
	(48,'CaseStudyCategoriesPage','2013-07-07 22:16:22','2013-07-07 22:17:09','packaging','Packaging',NULL,NULL,NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',3,11),
	(49,'CaseStudyCategoriesPage','2013-07-07 22:17:20','2013-07-07 22:17:46','resllers','Resllers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',3,11);

/*!40000 ALTER TABLE `SiteTree` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SiteTree_EditorGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_EditorGroups`;

CREATE TABLE `SiteTree_EditorGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteTree_ImageTracking
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_ImageTracking`;

CREATE TABLE `SiteTree_ImageTracking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `FileID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `FileID` (`FileID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteTree_LinkTracking
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_LinkTracking`;

CREATE TABLE `SiteTree_LinkTracking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `ChildID` (`ChildID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SiteTree_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_Live`;

CREATE TABLE `SiteTree_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Page','AboutPage','CaseStudyPage','ContactPage','HomePage','ErrorPage','BlogEntry','BlogHolder','SellingPage','CaseStudyCategoriesPage','SiteTree','BlogTree','RedirectorPage','VirtualPage') CHARACTER SET utf8 DEFAULT 'Page',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SiteTree_Live` WRITE;
/*!40000 ALTER TABLE `SiteTree_Live` DISABLE KEYS */;

INSERT INTO `SiteTree_Live` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `Version`, `ParentID`)
VALUES
	(6,'HomePage','2013-07-03 21:09:07','2013-07-07 22:31:17','home','Home',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,NULL,'Inherit','Inherit',7,0),
	(7,'AboutPage','2013-07-03 21:09:09','2013-07-03 21:09:33','about','About',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. <a href=\"http://loripsum.net/\" target=\"_blank\">Ea possunt paria non esse.</a> Duo Reges: constructio interrete. Sequitur disserendi ratio cognitioque naturae; </p>\n\n<p>Quis enim redargueret? Rationis enim perfectio est virtus; Si id dicis, vicimus. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Refert tamen, quo modo.</a> Ut pulsi recurrant? Itaque his sapiens semper vacabit. Duarum enim vitarum nobis erunt instituta capienda. Utram tandem linguam nescio? </p>\n\n<p>Bonum valitudo: miser morbus. Nihil sane. Tollenda est atque extrahenda radicitus. <a href=\"http://loripsum.net/\" target=\"_blank\">Polycratem Samium felicem appellabant.</a> Deinde dolorem quem maximum? Satis est ad hoc responsum. </p>\n\n<p>Si longus, levis dictata sunt. <a href=\"http://loripsum.net/\" target=\"_blank\">Eam stabilem appellas.</a> Pauca mutat vel plura sane; Stoici scilicet. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',1,0),
	(8,'SellingPage','2013-07-03 21:09:34','2013-07-07 16:57:19','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a></p>\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas.</p>\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum?</p>\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí?</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',6,7),
	(9,'SellingPage','2013-07-03 21:09:36','2013-07-07 17:00:01','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete.</p>\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius.</p>\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit?</p>\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',6,7),
	(10,'SellingPage','2013-07-03 21:09:37','2013-07-07 17:00:50','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis.</p>\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem.</p>\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita.</p>\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum.</p>\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat;</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',6,7),
	(11,'Page','2013-07-03 21:09:38','2013-07-07 22:32:37','case-studies','Case Studies',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',10,0),
	(17,'CaseStudyPage','2013-07-03 21:09:47','2013-07-07 22:33:45','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',12,41),
	(18,'CaseStudyPage','2013-07-03 21:09:52','2013-07-07 22:33:54','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio.</p>\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a></p>\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit.</p>\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio?</p>\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto;</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',12,41),
	(19,'CaseStudyPage','2013-07-03 21:09:57','2013-07-07 22:34:05','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni?</p>\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a></p>\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis.</p>\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem?</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto.</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11,41),
	(20,'CaseStudyPage','2013-07-03 21:10:02','2013-07-07 22:34:17','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete.</p>\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis;</p>\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas.</p>\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane.</p>\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa.</p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',10,41),
	(21,'CaseStudyPage','2013-07-03 21:10:08','2013-07-07 22:34:27','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio?</p>\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur?</p>\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a></p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn.</p>\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est?</p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11,41),
	(30,'ContactPage','2013-07-03 21:10:25','2013-07-03 21:10:25','contact-us','Contact Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proclivi currit oratio. Equidem e Cn. Duo Reges: constructio interrete. </p>\n\n<p>Sed haec in pueris; Ostendit pedes et pectus. Quid enim possumus hoc agere divinius? Quid iudicant sensus? Faceres tu quidem, Torquate, haec omnia; Eaedem res maneant alio modo. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Non est igitur voluptas bonum. Bonum patria: miserum exilium. Non est igitur voluptas bonum. Eadem fortitudinis ratio reperietur. </p>\n\n<p>Velut ego nunc moveor. Negare non possum. Peccata paria. Ut id aliis narrare gestiant? </p>\n\n<p>Dici enim nihil potest verius. Qui est in parvis malis. Tollenda est atque extrahenda radicitus. Illi enim inter se dissentiunt. </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',1,0),
	(31,'Page','2013-07-03 21:27:57','2013-07-03 21:28:08','resellers-2','Resellers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',2,0),
	(32,'Page','2013-07-03 21:29:48','2013-07-03 21:30:04','refer-us','Refer Us',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',2,0),
	(33,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','page-not-found','Page not found',NULL,'<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p>\n<p>Please check the spelling of the URL you were trying to access and try again.</p>',NULL,NULL,NULL,NULL,0,0,9,0,0,NULL,'Inherit','Inherit',1,0),
	(34,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','server-error','Server error',NULL,'<p>Sorry, there was a problem handling your request.</p>',NULL,NULL,NULL,NULL,0,0,10,0,0,NULL,'Inherit','Inherit',1,0),
	(35,'BlogHolder','2013-07-06 17:25:00','2013-07-06 17:25:00','blog','Blog',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',1,0),
	(36,'BlogEntry','2013-07-06 17:25:00','2013-07-06 17:25:00','sample-blog-entry','SilverStripe blog module successfully installed',NULL,'Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog (such as the widgets displayed in the sidebar) in [url=admin]the CMS[/url].',NULL,NULL,NULL,NULL,0,1,1,0,0,NULL,'Inherit','Inherit',1,35),
	(37,'CaseStudyCategoriesPage','2013-07-07 21:56:13','2013-07-07 22:03:30','transport','Transport',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',3,11),
	(38,'CaseStudyCategoriesPage','2013-07-07 22:03:42','2013-07-07 22:04:36','agriculture','Agriculture',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',3,11),
	(39,'CaseStudyCategoriesPage','2013-07-07 22:04:47','2013-07-07 22:07:00','mining','Mining',NULL,NULL,NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',3,11),
	(40,'CaseStudyCategoriesPage','2013-07-07 22:07:09','2013-07-07 22:07:44','infrastructure','Infrastructure',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',3,11),
	(41,'CaseStudyCategoriesPage','2013-07-07 22:07:52','2013-07-07 22:08:14','oil-and-gas','Oil & Gas',NULL,NULL,NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',3,11),
	(42,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:12:14','local-government','Local Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',5,11),
	(43,'CaseStudyCategoriesPage','2013-07-07 22:12:24','2013-07-07 22:13:36','manufacture-and-process','Manufacture & Process',NULL,NULL,NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',3,11),
	(44,'CaseStudyCategoriesPage','2013-07-07 22:13:44','2013-07-07 22:14:10','central-government','Central Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',3,11),
	(45,'CaseStudyCategoriesPage','2013-07-07 22:14:33','2013-07-07 22:14:55','defence','Defence',NULL,NULL,NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',3,11),
	(46,'CaseStudyCategoriesPage','2013-07-07 22:15:00','2013-07-07 22:15:18','services','Services',NULL,NULL,NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',3,11),
	(47,'CaseStudyCategoriesPage','2013-07-07 22:15:29','2013-07-07 22:16:14','energy','Energy',NULL,NULL,NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',3,11),
	(48,'CaseStudyCategoriesPage','2013-07-07 22:16:22','2013-07-07 22:17:09','packaging','Packaging',NULL,NULL,NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',3,11),
	(49,'CaseStudyCategoriesPage','2013-07-07 22:17:20','2013-07-07 22:17:46','resllers','Resllers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',3,11);

/*!40000 ALTER TABLE `SiteTree_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SiteTree_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_versions`;

CREATE TABLE `SiteTree_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('Page','AboutPage','CaseStudyPage','ContactPage','HomePage','ErrorPage','BlogEntry','BlogHolder','SellingPage','CaseStudyCategoriesPage','SiteTree','BlogTree','RedirectorPage','VirtualPage') CHARACTER SET utf8 DEFAULT 'Page',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `AuthorID` (`AuthorID`),
  KEY `PublisherID` (`PublisherID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `SiteTree_versions` WRITE;
/*!40000 ALTER TABLE `SiteTree_versions` DISABLE KEYS */;

INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ParentID`)
VALUES
	(6,6,1,0,0,0,'HomePage','2013-07-03 21:09:07','2013-07-03 21:09:07','home','Home',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non risu potius quam oratione eiciendum? Rationis enim perfectio est virtus; </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Sed hoc sane concedamus. Quae ista amicitia est? <a href=\"http://loripsum.net/\" target=\"_blank\">Quid Zeno?</a> </p>\n\n<p>Aliter enim nosmet ipsos nosse non possumus. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Quo tandem modo? Tu quidem reddes; </p>\n\n<p>Confecta res esset. Primum quid tu dicis breve? Equidem e Cn. Res enim concurrent contrariae. <a href=\"http://loripsum.net/\" target=\"_blank\">Idem iste, inquam, de voluptate quid sentit?</a> </p>\n\n<p>Bestiarum vero nullum iudicium puto. An potest cupiditas finiri? Quippe: habes enim a rhetoribus; Memini vero, inquam; </p>',NULL,NULL,NULL,NULL,1,1,0,0,0,NULL,'Inherit','Inherit',0),
	(7,6,2,1,0,0,'HomePage','2013-07-03 21:09:07','2013-07-03 21:09:08','home','Home',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non risu potius quam oratione eiciendum? Rationis enim perfectio est virtus; </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Sed hoc sane concedamus. Quae ista amicitia est? <a href=\"http://loripsum.net/\" target=\"_blank\">Quid Zeno?</a> </p>\n\n<p>Aliter enim nosmet ipsos nosse non possumus. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Quo tandem modo? Tu quidem reddes; </p>\n\n<p>Confecta res esset. Primum quid tu dicis breve? Equidem e Cn. Res enim concurrent contrariae. <a href=\"http://loripsum.net/\" target=\"_blank\">Idem iste, inquam, de voluptate quid sentit?</a> </p>\n\n<p>Bestiarum vero nullum iudicium puto. An potest cupiditas finiri? Quippe: habes enim a rhetoribus; Memini vero, inquam; </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(8,7,1,1,0,0,'AboutPage','2013-07-03 21:09:09','2013-07-03 21:09:09','about','About',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. <a href=\"http://loripsum.net/\" target=\"_blank\">Ea possunt paria non esse.</a> Duo Reges: constructio interrete. Sequitur disserendi ratio cognitioque naturae; </p>\n\n<p>Quis enim redargueret? Rationis enim perfectio est virtus; Si id dicis, vicimus. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Refert tamen, quo modo.</a> Ut pulsi recurrant? Itaque his sapiens semper vacabit. Duarum enim vitarum nobis erunt instituta capienda. Utram tandem linguam nescio? </p>\n\n<p>Bonum valitudo: miser morbus. Nihil sane. Tollenda est atque extrahenda radicitus. <a href=\"http://loripsum.net/\" target=\"_blank\">Polycratem Samium felicem appellabant.</a> Deinde dolorem quem maximum? Satis est ad hoc responsum. </p>\n\n<p>Si longus, levis dictata sunt. <a href=\"http://loripsum.net/\" target=\"_blank\">Eam stabilem appellas.</a> Pauca mutat vel plura sane; Stoici scilicet. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',0),
	(9,8,1,1,0,0,'Page','2013-07-03 21:09:34','2013-07-03 21:09:34','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> </p>\n\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas. </p>\n\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum? </p>\n\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí? </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(10,9,1,1,0,0,'Page','2013-07-03 21:09:36','2013-07-03 21:09:36','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete. </p>\n\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius. </p>\n\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit? </p>\n\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',0),
	(11,10,1,1,0,0,'Page','2013-07-03 21:09:37','2013-07-03 21:09:37','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis. </p>\n\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem. </p>\n\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita. </p>\n\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum. </p>\n\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat; </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',0),
	(12,11,1,1,0,0,'','2013-07-03 21:09:38','2013-07-03 21:09:38','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',0),
	(13,12,1,0,0,0,'','2013-07-03 21:09:40','2013-07-03 21:09:40','transport','Transport',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Certe non potest. Nam quid possumus facere melius? Haeret in salebra. Prave, nequiter, turpiter cenabat; Cur deinde Metrodori liberos commendas? Duo Reges: constructio interrete. Audeo dicere, inquit. </p>\n\n<p>Quis istud, quaeso, nesciebat? Quae duo sunt, unum facit. <a href=\"http://loripsum.net/\" target=\"_blank\">Zenonis est, inquam, hoc Stoici.</a> Non laboro, inquit, de nomine. Praeteritis, inquit, gaudeo. </p>\n\n<p>Moriatur, inquit. Est, ut dicis, inquit; Nemo igitur esse beatus potest. </p>\n\n<p>At enim hic etiam dolore. Quid de Platone aut de Democrito loquar? Ecce aliud simile dissimile. Inde igitur, inquit, ordiendum est. Laboro autem non sine causa; Quare conare, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Ostendit pedes et pectus.</a> </p>\n\n<p>Quibus ego vehementer assentior. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeteritis, inquit, gaudeo.</a> Confecta res esset. Quae sequuntur igitur? Non igitur bene. At hoc in eo M. </p>',NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',0),
	(14,12,2,1,0,0,'','2013-07-03 21:09:40','2013-07-03 21:09:40','transport','Transport',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Certe non potest. Nam quid possumus facere melius? Haeret in salebra. Prave, nequiter, turpiter cenabat; Cur deinde Metrodori liberos commendas? Duo Reges: constructio interrete. Audeo dicere, inquit. </p>\n\n<p>Quis istud, quaeso, nesciebat? Quae duo sunt, unum facit. <a href=\"http://loripsum.net/\" target=\"_blank\">Zenonis est, inquam, hoc Stoici.</a> Non laboro, inquit, de nomine. Praeteritis, inquit, gaudeo. </p>\n\n<p>Moriatur, inquit. Est, ut dicis, inquit; Nemo igitur esse beatus potest. </p>\n\n<p>At enim hic etiam dolore. Quid de Platone aut de Democrito loquar? Ecce aliud simile dissimile. Inde igitur, inquit, ordiendum est. Laboro autem non sine causa; Quare conare, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Ostendit pedes et pectus.</a> </p>\n\n<p>Quibus ego vehementer assentior. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeteritis, inquit, gaudeo.</a> Confecta res esset. Quae sequuntur igitur? Non igitur bene. At hoc in eo M. </p>',NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',0),
	(15,13,1,0,0,0,'','2013-07-03 21:09:41','2013-07-03 21:09:41','agriculture','Agriculture',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haec para/doca illi, nos admirabilia dicamus. Scrupulum, inquam, abeunti; Duo Reges: constructio interrete. Restinguet citius, si ardentem acceperit. Tum Torquatus: Prorsus, inquit, assentior; Efficiens dici potest. </p>\n\n<p>Quis est tam dissimile homini. <a href=\"http://loripsum.net/\" target=\"_blank\">Ita prorsus, inquam;</a> Hunc vos beatum; Quamquam te quidem video minime esse deterritum. </p>\n\n<p>Contineo me ab exemplis. Itaque his sapiens semper vacabit. Istic sum, inquit. At certe gravius. Ostendit pedes et pectus. Tria genera bonorum; </p>\n\n<p>Iam enim adesse poterit. Non semper, inquam; </p>\n\n<p>Frater et T. Quid est igitur, inquit, quod requiras? Nos vero, inquit ille; Dici enim nihil potest verius. Haec dicuntur fortasse ieiunius; An eiusdem modi? Quippe: habes enim a rhetoribus; Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',0),
	(16,13,2,1,0,0,'','2013-07-03 21:09:41','2013-07-03 21:09:41','agriculture','Agriculture',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haec para/doca illi, nos admirabilia dicamus. Scrupulum, inquam, abeunti; Duo Reges: constructio interrete. Restinguet citius, si ardentem acceperit. Tum Torquatus: Prorsus, inquit, assentior; Efficiens dici potest. </p>\n\n<p>Quis est tam dissimile homini. <a href=\"http://loripsum.net/\" target=\"_blank\">Ita prorsus, inquam;</a> Hunc vos beatum; Quamquam te quidem video minime esse deterritum. </p>\n\n<p>Contineo me ab exemplis. Itaque his sapiens semper vacabit. Istic sum, inquit. At certe gravius. Ostendit pedes et pectus. Tria genera bonorum; </p>\n\n<p>Iam enim adesse poterit. Non semper, inquam; </p>\n\n<p>Frater et T. Quid est igitur, inquit, quod requiras? Nos vero, inquit ille; Dici enim nihil potest verius. Haec dicuntur fortasse ieiunius; An eiusdem modi? Quippe: habes enim a rhetoribus; Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',0),
	(17,14,1,0,0,0,'','2013-07-03 21:09:42','2013-07-03 21:09:42','mining','Mining',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed virtutem ipsam inchoavit, nihil amplius. Confecta res esset. Falli igitur possumus. Summum a vobis bonum voluptas dicitur. </p>\n\n<p>Non est igitur voluptas bonum. Igitur ne dolorem quidem. Quid nunc honeste dicit? Immo alio genere; </p>\n\n<p>Sint modo partes vitae beatae. Beatus sibi videtur esse moriens. Ille incendat? Conferam avum tuum Drusum cum C. Quid iudicant sensus? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Sed virtutem ipsam inchoavit, nihil amplius.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Quae sequuntur igitur?</a> Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Quid iudicant sensus?</a> Compensabatur, inquit, cum summis doloribus laetitia. Illi enim inter se dissentiunt. </p>\n\n<p>At enim sequor utilitatem. Tum Torquatus: Prorsus, inquit, assentior; <a href=\"http://loripsum.net/\" target=\"_blank\">Gerendus est mos, modo recte sentiat.</a> Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',0),
	(18,14,2,1,0,0,'','2013-07-03 21:09:42','2013-07-03 21:09:42','mining','Mining',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed virtutem ipsam inchoavit, nihil amplius. Confecta res esset. Falli igitur possumus. Summum a vobis bonum voluptas dicitur. </p>\n\n<p>Non est igitur voluptas bonum. Igitur ne dolorem quidem. Quid nunc honeste dicit? Immo alio genere; </p>\n\n<p>Sint modo partes vitae beatae. Beatus sibi videtur esse moriens. Ille incendat? Conferam avum tuum Drusum cum C. Quid iudicant sensus? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Sed virtutem ipsam inchoavit, nihil amplius.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Quae sequuntur igitur?</a> Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Quid iudicant sensus?</a> Compensabatur, inquit, cum summis doloribus laetitia. Illi enim inter se dissentiunt. </p>\n\n<p>At enim sequor utilitatem. Tum Torquatus: Prorsus, inquit, assentior; <a href=\"http://loripsum.net/\" target=\"_blank\">Gerendus est mos, modo recte sentiat.</a> Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',0),
	(19,15,1,0,0,0,'','2013-07-03 21:09:44','2013-07-03 21:09:44','infrastructure','Infrastructure',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. Omnia peccata paria dicitis. Ratio quidem vestra sic cogit. Qui est in parvis malis. </p>\n\n<p>Idemne, quod iucunde? An nisi populari fama? Quid censes in Latino fore? </p>\n\n<p>Simus igitur contenti his. Non igitur bene. Duo Reges: constructio interrete. Prave, nequiter, turpiter cenabat; Bestiarum vero nullum iudicium puto. </p>\n\n<p>Quae cum essent dicta, discessimus. Quorum altera prosunt, nocent altera. Quis enim redargueret? Deinde dolorem quem maximum? Quid sequatur, quid repugnet, vident. Tu vero, inquam, ducas licet, si sequetur; Confecta res esset. <a href=\"http://loripsum.net/\" target=\"_blank\">Huius, Lyco, oratione locuples, rebus ipsis ielunior.</a> </p>\n\n<p>Polycratem Samium felicem appellabant. Falli igitur possumus. Sed ad bona praeterita redeamus. </p>',NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',0),
	(20,15,2,1,0,0,'','2013-07-03 21:09:44','2013-07-03 21:09:44','infrastructure','Infrastructure',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. Omnia peccata paria dicitis. Ratio quidem vestra sic cogit. Qui est in parvis malis. </p>\n\n<p>Idemne, quod iucunde? An nisi populari fama? Quid censes in Latino fore? </p>\n\n<p>Simus igitur contenti his. Non igitur bene. Duo Reges: constructio interrete. Prave, nequiter, turpiter cenabat; Bestiarum vero nullum iudicium puto. </p>\n\n<p>Quae cum essent dicta, discessimus. Quorum altera prosunt, nocent altera. Quis enim redargueret? Deinde dolorem quem maximum? Quid sequatur, quid repugnet, vident. Tu vero, inquam, ducas licet, si sequetur; Confecta res esset. <a href=\"http://loripsum.net/\" target=\"_blank\">Huius, Lyco, oratione locuples, rebus ipsis ielunior.</a> </p>\n\n<p>Polycratem Samium felicem appellabant. Falli igitur possumus. Sed ad bona praeterita redeamus. </p>',NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',0),
	(21,16,1,0,0,0,'','2013-07-03 21:09:46','2013-07-03 21:09:46','oil-and-gas','Oil and Gas',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sint ista Graecorum; Cur iustitia laudatur? Tibi hoc incredibile, quod beatissimum. <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Profectus in exilium Tubulus statim nec respondere ausus; Quae duo sunt, unum facit. Optime, inquam. Duo Reges: constructio interrete. </p>\n\n<p>Sed quae tandem ista ratio est? Hic ambiguo ludimur. Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">De quibus cupio scire quid sentias.</a> Etiam beatissimum? Sint ista Graecorum; </p>\n\n<p>Quid me istud rogas? Rationis enim perfectio est virtus; Prave, nequiter, turpiter cenabat; Itaque ab his ordiamur. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur, nisi quod turpis oratio est?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Suo genere perveniant ad extremum;</a> </p>\n\n<p>Invidiosum nomen est, infame, suspectum. Prave, nequiter, turpiter cenabat; Et nemo nimium beatus est; Pugnant Stoici cum Peripateticis. </p>',NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',0),
	(22,16,2,1,0,0,'','2013-07-03 21:09:46','2013-07-03 21:09:46','oil-and-gas','Oil and Gas',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sint ista Graecorum; Cur iustitia laudatur? Tibi hoc incredibile, quod beatissimum. <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Profectus in exilium Tubulus statim nec respondere ausus; Quae duo sunt, unum facit. Optime, inquam. Duo Reges: constructio interrete. </p>\n\n<p>Sed quae tandem ista ratio est? Hic ambiguo ludimur. Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">De quibus cupio scire quid sentias.</a> Etiam beatissimum? Sint ista Graecorum; </p>\n\n<p>Quid me istud rogas? Rationis enim perfectio est virtus; Prave, nequiter, turpiter cenabat; Itaque ab his ordiamur. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur, nisi quod turpis oratio est?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Suo genere perveniant ad extremum;</a> </p>\n\n<p>Invidiosum nomen est, infame, suspectum. Prave, nequiter, turpiter cenabat; Et nemo nimium beatus est; Pugnant Stoici cum Peripateticis. </p>',NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',0),
	(23,17,1,0,0,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-03 21:09:47','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',0),
	(24,17,2,1,0,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-03 21:09:51','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',0),
	(25,18,1,0,0,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-03 21:09:52','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',0),
	(26,18,2,1,0,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-03 21:09:56','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',0),
	(27,19,1,0,0,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-03 21:09:57','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',0),
	(28,19,2,1,0,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-03 21:10:01','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',0),
	(29,20,1,0,0,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-03 21:10:02','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',0),
	(30,20,2,1,0,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-03 21:10:06','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',0),
	(31,21,1,0,0,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-03 21:10:08','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',0),
	(32,21,2,1,0,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-03 21:10:11','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',0),
	(33,22,1,0,0,0,'','2013-07-03 21:10:13','2013-07-03 21:10:13','local-government','Local Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non quam nostram quidem, inquit Pomponius iocans; Torquatus, is qui consul cum Cn. Id mihi magnum videtur. Hoc non est positum in nostra actione. At multis se probavit. Duo Reges: constructio interrete. </p>\n\n<p>Sed residamus, inquit, si placet. Eadem fortitudinis ratio reperietur. Beatum, inquit. Numquam facies. An eiusdem modi? Et quidem, inquit, vehementer errat; </p>\n\n<p>Bonum patria: miserum exilium. Peccata paria. Sequitur disserendi ratio cognitioque naturae; Explanetur igitur. Venit ad extremum; Tu quidem reddes; </p>\n\n<p>Occultum facinus esse potuerit, gaudebit; Idem iste, inquam, de voluptate quid sentit? Non potes, nisi retexueris illa. Id Sextilius factum negabat. </p>\n\n<p>Minime vero istorum quidem, inquit. Istic sum, inquit. Et quidem, inquit, vehementer errat; Fortemne possumus dicere eundem illum Torquatum? Quonam, inquit, modo? </p>',NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',0),
	(34,22,2,1,0,0,'','2013-07-03 21:10:13','2013-07-03 21:10:13','local-government','Local Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non quam nostram quidem, inquit Pomponius iocans; Torquatus, is qui consul cum Cn. Id mihi magnum videtur. Hoc non est positum in nostra actione. At multis se probavit. Duo Reges: constructio interrete. </p>\n\n<p>Sed residamus, inquit, si placet. Eadem fortitudinis ratio reperietur. Beatum, inquit. Numquam facies. An eiusdem modi? Et quidem, inquit, vehementer errat; </p>\n\n<p>Bonum patria: miserum exilium. Peccata paria. Sequitur disserendi ratio cognitioque naturae; Explanetur igitur. Venit ad extremum; Tu quidem reddes; </p>\n\n<p>Occultum facinus esse potuerit, gaudebit; Idem iste, inquam, de voluptate quid sentit? Non potes, nisi retexueris illa. Id Sextilius factum negabat. </p>\n\n<p>Minime vero istorum quidem, inquit. Istic sum, inquit. Et quidem, inquit, vehementer errat; Fortemne possumus dicere eundem illum Torquatum? Quonam, inquit, modo? </p>',NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',0),
	(35,23,1,0,0,0,'','2013-07-03 21:10:14','2013-07-03 21:10:14','manufacture-and-process','Manufacture and Process',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Hoc mihi cum tuo fratre convenit. Sed hoc sane concedamus. An potest cupiditas finiri? Nemo igitur esse beatus potest. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Hos contra singulos dici est melius.</a> Et quidem, inquit, vehementer errat; Sed nimis multa. Quid enim? At eum nihili facit; Sed ego in hoc resisto; Quid sequatur, quid repugnet, vident. Sed ad illum redeo. </p>\n\n<p>Quid ergo? Eam tum adesse, cum dolor omnis absit; Haeret in salebra. Haec dicuntur inconstantissime. Sed hoc sane concedamus. </p>\n\n<p>Obsecro, inquit, Torquate, haec dicit Epicurus? Avaritiamne minuis? Duo Reges: constructio interrete. Efficiens dici potest. Sumenda potius quam expetenda. Vide, quantum, inquam, fallare, Torquate. </p>\n\n<p>Laboro autem non sine causa; Equidem, sed audistine modo de Carneade? Immo alio genere; Sed haec in pueris; Quis istud possit, inquit, negare? At enim hic etiam dolore. Erat enim Polemonis. </p>',NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',0),
	(36,23,2,1,0,0,'','2013-07-03 21:10:14','2013-07-03 21:10:14','manufacture-and-process','Manufacture and Process',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Hoc mihi cum tuo fratre convenit. Sed hoc sane concedamus. An potest cupiditas finiri? Nemo igitur esse beatus potest. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Hos contra singulos dici est melius.</a> Et quidem, inquit, vehementer errat; Sed nimis multa. Quid enim? At eum nihili facit; Sed ego in hoc resisto; Quid sequatur, quid repugnet, vident. Sed ad illum redeo. </p>\n\n<p>Quid ergo? Eam tum adesse, cum dolor omnis absit; Haeret in salebra. Haec dicuntur inconstantissime. Sed hoc sane concedamus. </p>\n\n<p>Obsecro, inquit, Torquate, haec dicit Epicurus? Avaritiamne minuis? Duo Reges: constructio interrete. Efficiens dici potest. Sumenda potius quam expetenda. Vide, quantum, inquam, fallare, Torquate. </p>\n\n<p>Laboro autem non sine causa; Equidem, sed audistine modo de Carneade? Immo alio genere; Sed haec in pueris; Quis istud possit, inquit, negare? At enim hic etiam dolore. Erat enim Polemonis. </p>',NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',0),
	(37,24,1,0,0,0,'','2013-07-03 21:10:17','2013-07-03 21:10:17','central-government','Central Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod totum contra est. <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Ad eos igitur converte te, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Proclivi currit oratio.</a> Duo Reges: constructio interrete. </p>\n\n<p>Hoc simile tandem est? Istam voluptatem, inquit, Epicurus ignorat? Moriatur, inquit. Ut id aliis narrare gestiant? Idem iste, inquam, de voluptate quid sentit? Proclivi currit oratio. <a href=\"http://loripsum.net/\" target=\"_blank\">Graece donan, Latine voluptatem vocant.</a> </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Hunc vos beatum; Nemo igitur esse beatus potest. Quae contraria sunt his, malane? </p>\n\n<p>Que Manilium, ab iisque M. Quae cum essent dicta, discessimus. At hoc in eo M. </p>\n\n<p>Recte dicis; Est, ut dicis, inquam. Quo tandem modo? Quare ad ea primum, si videtur; Ego vero isti, inquam, permitto. Vide, quantum, inquam, fallare, Torquate. </p>',NULL,NULL,NULL,NULL,1,1,19,0,0,NULL,'Inherit','Inherit',0),
	(38,24,2,1,0,0,'','2013-07-03 21:10:17','2013-07-03 21:10:17','central-government','Central Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod totum contra est. <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Ad eos igitur converte te, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Proclivi currit oratio.</a> Duo Reges: constructio interrete. </p>\n\n<p>Hoc simile tandem est? Istam voluptatem, inquit, Epicurus ignorat? Moriatur, inquit. Ut id aliis narrare gestiant? Idem iste, inquam, de voluptate quid sentit? Proclivi currit oratio. <a href=\"http://loripsum.net/\" target=\"_blank\">Graece donan, Latine voluptatem vocant.</a> </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Hunc vos beatum; Nemo igitur esse beatus potest. Quae contraria sunt his, malane? </p>\n\n<p>Que Manilium, ab iisque M. Quae cum essent dicta, discessimus. At hoc in eo M. </p>\n\n<p>Recte dicis; Est, ut dicis, inquam. Quo tandem modo? Quare ad ea primum, si videtur; Ego vero isti, inquam, permitto. Vide, quantum, inquam, fallare, Torquate. </p>',NULL,NULL,NULL,NULL,1,1,19,0,0,NULL,'Inherit','Inherit',0),
	(39,25,1,0,0,0,'','2013-07-03 21:10:18','2013-07-03 21:10:18','defence','Defence',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Fortemne possumus dicere eundem illum Torquatum?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sequitur disserendi ratio cognitioque naturae;</a> Sint ista Graecorum; Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> </p>\n\n<p>Quae est igitur causa istarum angustiarum? Sed nimis multa. </p>\n\n<p>Ut id aliis narrare gestiant? Confecta res esset. Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Mihi enim satis est, ipsis non satis.</a> Suo genere perveniant ad extremum; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Itaque hic ipse iam pridem est reiectus;</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Nos vero, inquit ille;</a> Prodest, inquit, mihi eo esse animo. Quae duo sunt, unum facit. Quid igitur, inquit, eos responsuros putas? Negare non possum. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> Idemne, quod iucunde? <a href=\"http://loripsum.net/\" target=\"_blank\">Haec dicuntur inconstantissime.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc est non dividere, sed frangere.</a> Quae cum essent dicta, discessimus. </p>',NULL,NULL,NULL,NULL,1,1,20,0,0,NULL,'Inherit','Inherit',0),
	(40,25,2,1,0,0,'','2013-07-03 21:10:18','2013-07-03 21:10:18','defence','Defence',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Fortemne possumus dicere eundem illum Torquatum?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sequitur disserendi ratio cognitioque naturae;</a> Sint ista Graecorum; Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> </p>\n\n<p>Quae est igitur causa istarum angustiarum? Sed nimis multa. </p>\n\n<p>Ut id aliis narrare gestiant? Confecta res esset. Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Mihi enim satis est, ipsis non satis.</a> Suo genere perveniant ad extremum; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Itaque hic ipse iam pridem est reiectus;</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Nos vero, inquit ille;</a> Prodest, inquit, mihi eo esse animo. Quae duo sunt, unum facit. Quid igitur, inquit, eos responsuros putas? Negare non possum. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> Idemne, quod iucunde? <a href=\"http://loripsum.net/\" target=\"_blank\">Haec dicuntur inconstantissime.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc est non dividere, sed frangere.</a> Quae cum essent dicta, discessimus. </p>',NULL,NULL,NULL,NULL,1,1,20,0,0,NULL,'Inherit','Inherit',0),
	(41,26,1,0,0,0,'','2013-07-03 21:10:20','2013-07-03 21:10:20','services','Services',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quae cum essent dicta, discessimus. <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> </p>\n\n<p>Praeclare hoc quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Summum a vobis bonum voluptas dicitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Idemne, quod iucunde?</a> Haec dicuntur inconstantissime. <a href=\"http://loripsum.net/\" target=\"_blank\">Easdemne res?</a> Et nemo nimium beatus est; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Odium autem et invidiam facile vitabis.</a> Occultum facinus esse potuerit, gaudebit; Sic enim censent, oportunitatis esse beate vivere. <a href=\"http://loripsum.net/\" target=\"_blank\">Perge porro;</a> </p>\n\n<p>Sed ille, ut dixi, vitiose. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Videsne, ut haec concinant? </p>\n\n<p>Duo Reges: constructio interrete. Primum divisit ineleganter; <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> Quid enim possumus hoc agere divinius? At iam decimum annum in spelunca iacet. </p>',NULL,NULL,NULL,NULL,1,1,21,0,0,NULL,'Inherit','Inherit',0),
	(42,26,2,1,0,0,'','2013-07-03 21:10:20','2013-07-03 21:10:20','services','Services',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quae cum essent dicta, discessimus. <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> </p>\n\n<p>Praeclare hoc quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Summum a vobis bonum voluptas dicitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Idemne, quod iucunde?</a> Haec dicuntur inconstantissime. <a href=\"http://loripsum.net/\" target=\"_blank\">Easdemne res?</a> Et nemo nimium beatus est; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Odium autem et invidiam facile vitabis.</a> Occultum facinus esse potuerit, gaudebit; Sic enim censent, oportunitatis esse beate vivere. <a href=\"http://loripsum.net/\" target=\"_blank\">Perge porro;</a> </p>\n\n<p>Sed ille, ut dixi, vitiose. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Videsne, ut haec concinant? </p>\n\n<p>Duo Reges: constructio interrete. Primum divisit ineleganter; <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> Quid enim possumus hoc agere divinius? At iam decimum annum in spelunca iacet. </p>',NULL,NULL,NULL,NULL,1,1,21,0,0,NULL,'Inherit','Inherit',0),
	(43,27,1,0,0,0,'','2013-07-03 21:10:21','2013-07-03 21:10:21','energy','Energy',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. At eum nihili facit; Hoc loco tenere se Triarius non potuit. Bonum incolumis acies: misera caecitas. Tum ille: Ain tandem? Primum in nostrane potestate est, quid meminerimus? </p>\n\n<p>Istic sum, inquit. Nulla erit controversia. Restinguet citius, si ardentem acceperit. Itaque ab his ordiamur. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quid autem habent admirationis, cum prope accesseris?</a> Rhetorice igitur, inquam, nos mavis quam dialectice disputare? Sed tamen intellego quid velit. Scaevolam M. Immo alio genere; Quibus ego vehementer assentior. </p>\n\n<p>Efficiens dici potest. Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Itaque contra est, ac dicitis;</a> Certe, nisi voluptatem tanti aestimaretis. </p>\n\n<p>Illud non continuo, ut aeque incontentae. Quid autem habent admirationis, cum prope accesseris? Equidem, sed audistine modo de Carneade? Eaedem res maneant alio modo. <a href=\"http://loripsum.net/\" target=\"_blank\">Neutrum vero, inquit ille.</a> Aliter homines, aliter philosophos loqui putas oportere? </p>',NULL,NULL,NULL,NULL,1,1,22,0,0,NULL,'Inherit','Inherit',0),
	(44,27,2,1,0,0,'','2013-07-03 21:10:21','2013-07-03 21:10:21','energy','Energy',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. At eum nihili facit; Hoc loco tenere se Triarius non potuit. Bonum incolumis acies: misera caecitas. Tum ille: Ain tandem? Primum in nostrane potestate est, quid meminerimus? </p>\n\n<p>Istic sum, inquit. Nulla erit controversia. Restinguet citius, si ardentem acceperit. Itaque ab his ordiamur. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quid autem habent admirationis, cum prope accesseris?</a> Rhetorice igitur, inquam, nos mavis quam dialectice disputare? Sed tamen intellego quid velit. Scaevolam M. Immo alio genere; Quibus ego vehementer assentior. </p>\n\n<p>Efficiens dici potest. Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Itaque contra est, ac dicitis;</a> Certe, nisi voluptatem tanti aestimaretis. </p>\n\n<p>Illud non continuo, ut aeque incontentae. Quid autem habent admirationis, cum prope accesseris? Equidem, sed audistine modo de Carneade? Eaedem res maneant alio modo. <a href=\"http://loripsum.net/\" target=\"_blank\">Neutrum vero, inquit ille.</a> Aliter homines, aliter philosophos loqui putas oportere? </p>',NULL,NULL,NULL,NULL,1,1,22,0,0,NULL,'Inherit','Inherit',0),
	(45,28,1,0,0,0,'','2013-07-03 21:10:22','2013-07-03 21:10:22','packaging','Packaging',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Qualem igitur hominem natura inchoavit?</a> Cur id non ita fit? </p>\n\n<p>Non potes, nisi retexueris illa. Videsne quam sit magna dissensio? Avaritiamne minuis? Duo Reges: constructio interrete. Ut pulsi recurrant? Confecta res esset. </p>\n\n<p>Hoc ipsum elegantius poni meliusque potuit. Audeo dicere, inquit. Prioris generis est docilitas, memoria; Minime vero, inquit ille, consentit. Si quae forte-possumus. Quare attende, quaeso. Sed ille, ut dixi, vitiose. Venit ad extremum; </p>\n\n<p>Eam stabilem appellas. Praeteritis, inquit, gaudeo. <a href=\"http://loripsum.net/\" target=\"_blank\">Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse;</a> Quibus ego vehementer assentior. Nunc agendum est subtilius. </p>\n\n<p>Certe non potest. Addidisti ad extremum etiam indoctum fuisse. Igitur ne dolorem quidem. Praeteritis, inquit, gaudeo. Sit enim idem caecus, debilis. Hic ambiguo ludimur. </p>',NULL,NULL,NULL,NULL,1,1,23,0,0,NULL,'Inherit','Inherit',0),
	(46,28,2,1,0,0,'','2013-07-03 21:10:22','2013-07-03 21:10:22','packaging','Packaging',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Qualem igitur hominem natura inchoavit?</a> Cur id non ita fit? </p>\n\n<p>Non potes, nisi retexueris illa. Videsne quam sit magna dissensio? Avaritiamne minuis? Duo Reges: constructio interrete. Ut pulsi recurrant? Confecta res esset. </p>\n\n<p>Hoc ipsum elegantius poni meliusque potuit. Audeo dicere, inquit. Prioris generis est docilitas, memoria; Minime vero, inquit ille, consentit. Si quae forte-possumus. Quare attende, quaeso. Sed ille, ut dixi, vitiose. Venit ad extremum; </p>\n\n<p>Eam stabilem appellas. Praeteritis, inquit, gaudeo. <a href=\"http://loripsum.net/\" target=\"_blank\">Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse;</a> Quibus ego vehementer assentior. Nunc agendum est subtilius. </p>\n\n<p>Certe non potest. Addidisti ad extremum etiam indoctum fuisse. Igitur ne dolorem quidem. Praeteritis, inquit, gaudeo. Sit enim idem caecus, debilis. Hic ambiguo ludimur. </p>',NULL,NULL,NULL,NULL,1,1,23,0,0,NULL,'Inherit','Inherit',0),
	(47,29,1,0,0,0,'','2013-07-03 21:10:23','2013-07-03 21:10:23','resellers','Resellers',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tum ille: Ain tandem? <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Duo Reges: constructio interrete. Age sane, inquam. Laboro autem non sine causa; Sed haec omittamus; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Tollenda est atque extrahenda radicitus.</a> Non igitur bene. Peccata paria. </p>\n\n<p>Teneo, inquit, finem illi videri nihil dolere. Eam stabilem appellas. </p>\n\n<p>Perge porro; Respondent extrema primis, media utrisque, omnia omnibus. Quorum sine causa fieri nihil putandum est. Compensabatur, inquit, cum summis doloribus laetitia. </p>\n\n<p>Age sane, inquam. Zenonis est, inquam, hoc Stoici. </p>',NULL,NULL,NULL,NULL,1,1,24,0,0,NULL,'Inherit','Inherit',0),
	(48,29,2,1,0,0,'','2013-07-03 21:10:23','2013-07-03 21:10:23','resellers','Resellers',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tum ille: Ain tandem? <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Duo Reges: constructio interrete. Age sane, inquam. Laboro autem non sine causa; Sed haec omittamus; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Tollenda est atque extrahenda radicitus.</a> Non igitur bene. Peccata paria. </p>\n\n<p>Teneo, inquit, finem illi videri nihil dolere. Eam stabilem appellas. </p>\n\n<p>Perge porro; Respondent extrema primis, media utrisque, omnia omnibus. Quorum sine causa fieri nihil putandum est. Compensabatur, inquit, cum summis doloribus laetitia. </p>\n\n<p>Age sane, inquam. Zenonis est, inquam, hoc Stoici. </p>',NULL,NULL,NULL,NULL,1,1,24,0,0,NULL,'Inherit','Inherit',0),
	(49,30,1,1,0,0,'ContactPage','2013-07-03 21:10:25','2013-07-03 21:10:25','contact-us','Contact Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proclivi currit oratio. Equidem e Cn. Duo Reges: constructio interrete. </p>\n\n<p>Sed haec in pueris; Ostendit pedes et pectus. Quid enim possumus hoc agere divinius? Quid iudicant sensus? Faceres tu quidem, Torquate, haec omnia; Eaedem res maneant alio modo. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Non est igitur voluptas bonum. Bonum patria: miserum exilium. Non est igitur voluptas bonum. Eadem fortitudinis ratio reperietur. </p>\n\n<p>Velut ego nunc moveor. Negare non possum. Peccata paria. Ut id aliis narrare gestiant? </p>\n\n<p>Dici enim nihil potest verius. Qui est in parvis malis. Tollenda est atque extrahenda radicitus. Illi enim inter se dissentiunt. </p>',NULL,NULL,NULL,NULL,1,1,25,0,0,NULL,'Inherit','Inherit',0),
	(50,17,3,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-03 21:22:54','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',16),
	(51,17,4,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-03 21:22:54','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',16),
	(52,18,3,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-03 21:23:00','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',16),
	(53,18,4,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-03 21:23:00','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',16),
	(54,19,3,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-03 21:23:03','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',16),
	(55,19,4,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-03 21:23:04','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',16),
	(56,20,3,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-03 21:23:07','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',16),
	(57,20,4,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-03 21:23:07','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',16),
	(58,21,3,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-03 21:23:11','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',16),
	(59,21,4,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-03 21:23:11','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',16),
	(60,12,3,0,1,0,'','2013-07-03 21:09:40','2013-07-03 21:23:22','transport','Transport',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Certe non potest. Nam quid possumus facere melius? Haeret in salebra. Prave, nequiter, turpiter cenabat; Cur deinde Metrodori liberos commendas? Duo Reges: constructio interrete. Audeo dicere, inquit. </p>\n\n<p>Quis istud, quaeso, nesciebat? Quae duo sunt, unum facit. <a href=\"http://loripsum.net/\" target=\"_blank\">Zenonis est, inquam, hoc Stoici.</a> Non laboro, inquit, de nomine. Praeteritis, inquit, gaudeo. </p>\n\n<p>Moriatur, inquit. Est, ut dicis, inquit; Nemo igitur esse beatus potest. </p>\n\n<p>At enim hic etiam dolore. Quid de Platone aut de Democrito loquar? Ecce aliud simile dissimile. Inde igitur, inquit, ordiendum est. Laboro autem non sine causa; Quare conare, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Ostendit pedes et pectus.</a> </p>\n\n<p>Quibus ego vehementer assentior. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeteritis, inquit, gaudeo.</a> Confecta res esset. Quae sequuntur igitur? Non igitur bene. At hoc in eo M. </p>',NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',11),
	(61,12,4,0,1,0,'','2013-07-03 21:09:40','2013-07-03 21:23:22','transport','Transport',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Certe non potest. Nam quid possumus facere melius? Haeret in salebra. Prave, nequiter, turpiter cenabat; Cur deinde Metrodori liberos commendas? Duo Reges: constructio interrete. Audeo dicere, inquit. </p>\n\n<p>Quis istud, quaeso, nesciebat? Quae duo sunt, unum facit. <a href=\"http://loripsum.net/\" target=\"_blank\">Zenonis est, inquam, hoc Stoici.</a> Non laboro, inquit, de nomine. Praeteritis, inquit, gaudeo. </p>\n\n<p>Moriatur, inquit. Est, ut dicis, inquit; Nemo igitur esse beatus potest. </p>\n\n<p>At enim hic etiam dolore. Quid de Platone aut de Democrito loquar? Ecce aliud simile dissimile. Inde igitur, inquit, ordiendum est. Laboro autem non sine causa; Quare conare, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Ostendit pedes et pectus.</a> </p>\n\n<p>Quibus ego vehementer assentior. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeteritis, inquit, gaudeo.</a> Confecta res esset. Quae sequuntur igitur? Non igitur bene. At hoc in eo M. </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',11),
	(62,13,3,0,1,0,'','2013-07-03 21:09:41','2013-07-03 21:23:51','agriculture','Agriculture',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haec para/doca illi, nos admirabilia dicamus. Scrupulum, inquam, abeunti; Duo Reges: constructio interrete. Restinguet citius, si ardentem acceperit. Tum Torquatus: Prorsus, inquit, assentior; Efficiens dici potest. </p>\n\n<p>Quis est tam dissimile homini. <a href=\"http://loripsum.net/\" target=\"_blank\">Ita prorsus, inquam;</a> Hunc vos beatum; Quamquam te quidem video minime esse deterritum. </p>\n\n<p>Contineo me ab exemplis. Itaque his sapiens semper vacabit. Istic sum, inquit. At certe gravius. Ostendit pedes et pectus. Tria genera bonorum; </p>\n\n<p>Iam enim adesse poterit. Non semper, inquam; </p>\n\n<p>Frater et T. Quid est igitur, inquit, quod requiras? Nos vero, inquit ille; Dici enim nihil potest verius. Haec dicuntur fortasse ieiunius; An eiusdem modi? Quippe: habes enim a rhetoribus; Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',11),
	(63,13,4,0,1,0,'','2013-07-03 21:09:41','2013-07-03 21:23:51','agriculture','Agriculture',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haec para/doca illi, nos admirabilia dicamus. Scrupulum, inquam, abeunti; Duo Reges: constructio interrete. Restinguet citius, si ardentem acceperit. Tum Torquatus: Prorsus, inquit, assentior; Efficiens dici potest. </p>\n\n<p>Quis est tam dissimile homini. <a href=\"http://loripsum.net/\" target=\"_blank\">Ita prorsus, inquam;</a> Hunc vos beatum; Quamquam te quidem video minime esse deterritum. </p>\n\n<p>Contineo me ab exemplis. Itaque his sapiens semper vacabit. Istic sum, inquit. At certe gravius. Ostendit pedes et pectus. Tria genera bonorum; </p>\n\n<p>Iam enim adesse poterit. Non semper, inquam; </p>\n\n<p>Frater et T. Quid est igitur, inquit, quod requiras? Nos vero, inquit ille; Dici enim nihil potest verius. Haec dicuntur fortasse ieiunius; An eiusdem modi? Quippe: habes enim a rhetoribus; Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',11),
	(64,14,3,0,1,0,'','2013-07-03 21:09:42','2013-07-03 21:23:56','mining','Mining',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed virtutem ipsam inchoavit, nihil amplius. Confecta res esset. Falli igitur possumus. Summum a vobis bonum voluptas dicitur. </p>\n\n<p>Non est igitur voluptas bonum. Igitur ne dolorem quidem. Quid nunc honeste dicit? Immo alio genere; </p>\n\n<p>Sint modo partes vitae beatae. Beatus sibi videtur esse moriens. Ille incendat? Conferam avum tuum Drusum cum C. Quid iudicant sensus? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Sed virtutem ipsam inchoavit, nihil amplius.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Quae sequuntur igitur?</a> Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Quid iudicant sensus?</a> Compensabatur, inquit, cum summis doloribus laetitia. Illi enim inter se dissentiunt. </p>\n\n<p>At enim sequor utilitatem. Tum Torquatus: Prorsus, inquit, assentior; <a href=\"http://loripsum.net/\" target=\"_blank\">Gerendus est mos, modo recte sentiat.</a> Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',11),
	(65,14,4,0,1,0,'','2013-07-03 21:09:42','2013-07-03 21:23:56','mining','Mining',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed virtutem ipsam inchoavit, nihil amplius. Confecta res esset. Falli igitur possumus. Summum a vobis bonum voluptas dicitur. </p>\n\n<p>Non est igitur voluptas bonum. Igitur ne dolorem quidem. Quid nunc honeste dicit? Immo alio genere; </p>\n\n<p>Sint modo partes vitae beatae. Beatus sibi videtur esse moriens. Ille incendat? Conferam avum tuum Drusum cum C. Quid iudicant sensus? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Sed virtutem ipsam inchoavit, nihil amplius.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Quae sequuntur igitur?</a> Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Quid iudicant sensus?</a> Compensabatur, inquit, cum summis doloribus laetitia. Illi enim inter se dissentiunt. </p>\n\n<p>At enim sequor utilitatem. Tum Torquatus: Prorsus, inquit, assentior; <a href=\"http://loripsum.net/\" target=\"_blank\">Gerendus est mos, modo recte sentiat.</a> Laboro autem non sine causa; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(66,15,3,0,1,0,'','2013-07-03 21:09:44','2013-07-03 21:24:02','infrastructure','Infrastructure',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. Omnia peccata paria dicitis. Ratio quidem vestra sic cogit. Qui est in parvis malis. </p>\n\n<p>Idemne, quod iucunde? An nisi populari fama? Quid censes in Latino fore? </p>\n\n<p>Simus igitur contenti his. Non igitur bene. Duo Reges: constructio interrete. Prave, nequiter, turpiter cenabat; Bestiarum vero nullum iudicium puto. </p>\n\n<p>Quae cum essent dicta, discessimus. Quorum altera prosunt, nocent altera. Quis enim redargueret? Deinde dolorem quem maximum? Quid sequatur, quid repugnet, vident. Tu vero, inquam, ducas licet, si sequetur; Confecta res esset. <a href=\"http://loripsum.net/\" target=\"_blank\">Huius, Lyco, oratione locuples, rebus ipsis ielunior.</a> </p>\n\n<p>Polycratem Samium felicem appellabant. Falli igitur possumus. Sed ad bona praeterita redeamus. </p>',NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',11),
	(67,15,4,0,1,0,'','2013-07-03 21:09:44','2013-07-03 21:24:02','infrastructure','Infrastructure',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Haeret in salebra. Omnia peccata paria dicitis. Ratio quidem vestra sic cogit. Qui est in parvis malis. </p>\n\n<p>Idemne, quod iucunde? An nisi populari fama? Quid censes in Latino fore? </p>\n\n<p>Simus igitur contenti his. Non igitur bene. Duo Reges: constructio interrete. Prave, nequiter, turpiter cenabat; Bestiarum vero nullum iudicium puto. </p>\n\n<p>Quae cum essent dicta, discessimus. Quorum altera prosunt, nocent altera. Quis enim redargueret? Deinde dolorem quem maximum? Quid sequatur, quid repugnet, vident. Tu vero, inquam, ducas licet, si sequetur; Confecta res esset. <a href=\"http://loripsum.net/\" target=\"_blank\">Huius, Lyco, oratione locuples, rebus ipsis ielunior.</a> </p>\n\n<p>Polycratem Samium felicem appellabant. Falli igitur possumus. Sed ad bona praeterita redeamus. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(68,16,3,0,1,0,'','2013-07-03 21:09:46','2013-07-03 21:24:10','oil-and-gas','Oil and Gas',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sint ista Graecorum; Cur iustitia laudatur? Tibi hoc incredibile, quod beatissimum. <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Profectus in exilium Tubulus statim nec respondere ausus; Quae duo sunt, unum facit. Optime, inquam. Duo Reges: constructio interrete. </p>\n\n<p>Sed quae tandem ista ratio est? Hic ambiguo ludimur. Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">De quibus cupio scire quid sentias.</a> Etiam beatissimum? Sint ista Graecorum; </p>\n\n<p>Quid me istud rogas? Rationis enim perfectio est virtus; Prave, nequiter, turpiter cenabat; Itaque ab his ordiamur. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur, nisi quod turpis oratio est?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Suo genere perveniant ad extremum;</a> </p>\n\n<p>Invidiosum nomen est, infame, suspectum. Prave, nequiter, turpiter cenabat; Et nemo nimium beatus est; Pugnant Stoici cum Peripateticis. </p>',NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(69,16,4,0,1,0,'','2013-07-03 21:09:46','2013-07-03 21:24:10','oil-and-gas','Oil and Gas',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sint ista Graecorum; Cur iustitia laudatur? Tibi hoc incredibile, quod beatissimum. <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Profectus in exilium Tubulus statim nec respondere ausus; Quae duo sunt, unum facit. Optime, inquam. Duo Reges: constructio interrete. </p>\n\n<p>Sed quae tandem ista ratio est? Hic ambiguo ludimur. Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">De quibus cupio scire quid sentias.</a> Etiam beatissimum? Sint ista Graecorum; </p>\n\n<p>Quid me istud rogas? Rationis enim perfectio est virtus; Prave, nequiter, turpiter cenabat; Itaque ab his ordiamur. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur, nisi quod turpis oratio est?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Suo genere perveniant ad extremum;</a> </p>\n\n<p>Invidiosum nomen est, infame, suspectum. Prave, nequiter, turpiter cenabat; Et nemo nimium beatus est; Pugnant Stoici cum Peripateticis. </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11),
	(70,22,3,0,1,0,'','2013-07-03 21:10:13','2013-07-03 21:24:13','local-government','Local Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non quam nostram quidem, inquit Pomponius iocans; Torquatus, is qui consul cum Cn. Id mihi magnum videtur. Hoc non est positum in nostra actione. At multis se probavit. Duo Reges: constructio interrete. </p>\n\n<p>Sed residamus, inquit, si placet. Eadem fortitudinis ratio reperietur. Beatum, inquit. Numquam facies. An eiusdem modi? Et quidem, inquit, vehementer errat; </p>\n\n<p>Bonum patria: miserum exilium. Peccata paria. Sequitur disserendi ratio cognitioque naturae; Explanetur igitur. Venit ad extremum; Tu quidem reddes; </p>\n\n<p>Occultum facinus esse potuerit, gaudebit; Idem iste, inquam, de voluptate quid sentit? Non potes, nisi retexueris illa. Id Sextilius factum negabat. </p>\n\n<p>Minime vero istorum quidem, inquit. Istic sum, inquit. Et quidem, inquit, vehementer errat; Fortemne possumus dicere eundem illum Torquatum? Quonam, inquit, modo? </p>',NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',11),
	(71,22,4,0,1,0,'','2013-07-03 21:10:13','2013-07-03 21:24:14','local-government','Local Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non quam nostram quidem, inquit Pomponius iocans; Torquatus, is qui consul cum Cn. Id mihi magnum videtur. Hoc non est positum in nostra actione. At multis se probavit. Duo Reges: constructio interrete. </p>\n\n<p>Sed residamus, inquit, si placet. Eadem fortitudinis ratio reperietur. Beatum, inquit. Numquam facies. An eiusdem modi? Et quidem, inquit, vehementer errat; </p>\n\n<p>Bonum patria: miserum exilium. Peccata paria. Sequitur disserendi ratio cognitioque naturae; Explanetur igitur. Venit ad extremum; Tu quidem reddes; </p>\n\n<p>Occultum facinus esse potuerit, gaudebit; Idem iste, inquam, de voluptate quid sentit? Non potes, nisi retexueris illa. Id Sextilius factum negabat. </p>\n\n<p>Minime vero istorum quidem, inquit. Istic sum, inquit. Et quidem, inquit, vehementer errat; Fortemne possumus dicere eundem illum Torquatum? Quonam, inquit, modo? </p>',NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',11),
	(72,23,3,0,1,0,'','2013-07-03 21:10:14','2013-07-03 21:24:17','manufacture-and-process','Manufacture and Process',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Hoc mihi cum tuo fratre convenit. Sed hoc sane concedamus. An potest cupiditas finiri? Nemo igitur esse beatus potest. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Hos contra singulos dici est melius.</a> Et quidem, inquit, vehementer errat; Sed nimis multa. Quid enim? At eum nihili facit; Sed ego in hoc resisto; Quid sequatur, quid repugnet, vident. Sed ad illum redeo. </p>\n\n<p>Quid ergo? Eam tum adesse, cum dolor omnis absit; Haeret in salebra. Haec dicuntur inconstantissime. Sed hoc sane concedamus. </p>\n\n<p>Obsecro, inquit, Torquate, haec dicit Epicurus? Avaritiamne minuis? Duo Reges: constructio interrete. Efficiens dici potest. Sumenda potius quam expetenda. Vide, quantum, inquam, fallare, Torquate. </p>\n\n<p>Laboro autem non sine causa; Equidem, sed audistine modo de Carneade? Immo alio genere; Sed haec in pueris; Quis istud possit, inquit, negare? At enim hic etiam dolore. Erat enim Polemonis. </p>',NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',11),
	(73,23,4,0,1,0,'','2013-07-03 21:10:14','2013-07-03 21:24:17','manufacture-and-process','Manufacture and Process',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Hoc mihi cum tuo fratre convenit. Sed hoc sane concedamus. An potest cupiditas finiri? Nemo igitur esse beatus potest. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Hos contra singulos dici est melius.</a> Et quidem, inquit, vehementer errat; Sed nimis multa. Quid enim? At eum nihili facit; Sed ego in hoc resisto; Quid sequatur, quid repugnet, vident. Sed ad illum redeo. </p>\n\n<p>Quid ergo? Eam tum adesse, cum dolor omnis absit; Haeret in salebra. Haec dicuntur inconstantissime. Sed hoc sane concedamus. </p>\n\n<p>Obsecro, inquit, Torquate, haec dicit Epicurus? Avaritiamne minuis? Duo Reges: constructio interrete. Efficiens dici potest. Sumenda potius quam expetenda. Vide, quantum, inquam, fallare, Torquate. </p>\n\n<p>Laboro autem non sine causa; Equidem, sed audistine modo de Carneade? Immo alio genere; Sed haec in pueris; Quis istud possit, inquit, negare? At enim hic etiam dolore. Erat enim Polemonis. </p>',NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',11),
	(74,24,3,0,1,0,'','2013-07-03 21:10:17','2013-07-03 21:24:22','central-government','Central Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod totum contra est. <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Ad eos igitur converte te, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Proclivi currit oratio.</a> Duo Reges: constructio interrete. </p>\n\n<p>Hoc simile tandem est? Istam voluptatem, inquit, Epicurus ignorat? Moriatur, inquit. Ut id aliis narrare gestiant? Idem iste, inquam, de voluptate quid sentit? Proclivi currit oratio. <a href=\"http://loripsum.net/\" target=\"_blank\">Graece donan, Latine voluptatem vocant.</a> </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Hunc vos beatum; Nemo igitur esse beatus potest. Quae contraria sunt his, malane? </p>\n\n<p>Que Manilium, ab iisque M. Quae cum essent dicta, discessimus. At hoc in eo M. </p>\n\n<p>Recte dicis; Est, ut dicis, inquam. Quo tandem modo? Quare ad ea primum, si videtur; Ego vero isti, inquam, permitto. Vide, quantum, inquam, fallare, Torquate. </p>',NULL,NULL,NULL,NULL,1,1,19,0,0,NULL,'Inherit','Inherit',11),
	(75,24,4,0,1,0,'','2013-07-03 21:10:17','2013-07-03 21:24:22','central-government','Central Government',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod totum contra est. <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Ad eos igitur converte te, quaeso. <a href=\"http://loripsum.net/\" target=\"_blank\">Proclivi currit oratio.</a> Duo Reges: constructio interrete. </p>\n\n<p>Hoc simile tandem est? Istam voluptatem, inquit, Epicurus ignorat? Moriatur, inquit. Ut id aliis narrare gestiant? Idem iste, inquam, de voluptate quid sentit? Proclivi currit oratio. <a href=\"http://loripsum.net/\" target=\"_blank\">Graece donan, Latine voluptatem vocant.</a> </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Hunc vos beatum; Nemo igitur esse beatus potest. Quae contraria sunt his, malane? </p>\n\n<p>Que Manilium, ab iisque M. Quae cum essent dicta, discessimus. At hoc in eo M. </p>\n\n<p>Recte dicis; Est, ut dicis, inquam. Quo tandem modo? Quare ad ea primum, si videtur; Ego vero isti, inquam, permitto. Vide, quantum, inquam, fallare, Torquate. </p>',NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',11),
	(76,25,3,0,1,0,'','2013-07-03 21:10:18','2013-07-03 21:24:27','defence','Defence',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Fortemne possumus dicere eundem illum Torquatum?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sequitur disserendi ratio cognitioque naturae;</a> Sint ista Graecorum; Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> </p>\n\n<p>Quae est igitur causa istarum angustiarum? Sed nimis multa. </p>\n\n<p>Ut id aliis narrare gestiant? Confecta res esset. Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Mihi enim satis est, ipsis non satis.</a> Suo genere perveniant ad extremum; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Itaque hic ipse iam pridem est reiectus;</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Nos vero, inquit ille;</a> Prodest, inquit, mihi eo esse animo. Quae duo sunt, unum facit. Quid igitur, inquit, eos responsuros putas? Negare non possum. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> Idemne, quod iucunde? <a href=\"http://loripsum.net/\" target=\"_blank\">Haec dicuntur inconstantissime.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc est non dividere, sed frangere.</a> Quae cum essent dicta, discessimus. </p>',NULL,NULL,NULL,NULL,1,1,20,0,0,NULL,'Inherit','Inherit',11),
	(77,25,4,0,1,0,'','2013-07-03 21:10:18','2013-07-03 21:24:27','defence','Defence',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Fortemne possumus dicere eundem illum Torquatum?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sequitur disserendi ratio cognitioque naturae;</a> Sint ista Graecorum; Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> </p>\n\n<p>Quae est igitur causa istarum angustiarum? Sed nimis multa. </p>\n\n<p>Ut id aliis narrare gestiant? Confecta res esset. Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Mihi enim satis est, ipsis non satis.</a> Suo genere perveniant ad extremum; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Itaque hic ipse iam pridem est reiectus;</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Nos vero, inquit ille;</a> Prodest, inquit, mihi eo esse animo. Quae duo sunt, unum facit. Quid igitur, inquit, eos responsuros putas? Negare non possum. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Respondeat totidem verbis.</a> Idemne, quod iucunde? <a href=\"http://loripsum.net/\" target=\"_blank\">Haec dicuntur inconstantissime.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc est non dividere, sed frangere.</a> Quae cum essent dicta, discessimus. </p>',NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',11),
	(78,26,3,0,1,0,'','2013-07-03 21:10:20','2013-07-03 21:24:31','services','Services',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quae cum essent dicta, discessimus. <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> </p>\n\n<p>Praeclare hoc quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Summum a vobis bonum voluptas dicitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Idemne, quod iucunde?</a> Haec dicuntur inconstantissime. <a href=\"http://loripsum.net/\" target=\"_blank\">Easdemne res?</a> Et nemo nimium beatus est; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Odium autem et invidiam facile vitabis.</a> Occultum facinus esse potuerit, gaudebit; Sic enim censent, oportunitatis esse beate vivere. <a href=\"http://loripsum.net/\" target=\"_blank\">Perge porro;</a> </p>\n\n<p>Sed ille, ut dixi, vitiose. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Videsne, ut haec concinant? </p>\n\n<p>Duo Reges: constructio interrete. Primum divisit ineleganter; <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> Quid enim possumus hoc agere divinius? At iam decimum annum in spelunca iacet. </p>',NULL,NULL,NULL,NULL,1,1,21,0,0,NULL,'Inherit','Inherit',11),
	(79,26,4,0,1,0,'','2013-07-03 21:10:20','2013-07-03 21:24:31','services','Services',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quae cum essent dicta, discessimus. <a href=\"http://loripsum.net/\" target=\"_blank\">Paria sunt igitur.</a> </p>\n\n<p>Praeclare hoc quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Summum a vobis bonum voluptas dicitur.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Idemne, quod iucunde?</a> Haec dicuntur inconstantissime. <a href=\"http://loripsum.net/\" target=\"_blank\">Easdemne res?</a> Et nemo nimium beatus est; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Odium autem et invidiam facile vitabis.</a> Occultum facinus esse potuerit, gaudebit; Sic enim censent, oportunitatis esse beate vivere. <a href=\"http://loripsum.net/\" target=\"_blank\">Perge porro;</a> </p>\n\n<p>Sed ille, ut dixi, vitiose. Huius, Lyco, oratione locuples, rebus ipsis ielunior. Videsne, ut haec concinant? </p>\n\n<p>Duo Reges: constructio interrete. Primum divisit ineleganter; <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> Quid enim possumus hoc agere divinius? At iam decimum annum in spelunca iacet. </p>',NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',11),
	(80,27,3,0,1,0,'','2013-07-03 21:10:21','2013-07-03 21:24:37','energy','Energy',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. At eum nihili facit; Hoc loco tenere se Triarius non potuit. Bonum incolumis acies: misera caecitas. Tum ille: Ain tandem? Primum in nostrane potestate est, quid meminerimus? </p>\n\n<p>Istic sum, inquit. Nulla erit controversia. Restinguet citius, si ardentem acceperit. Itaque ab his ordiamur. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quid autem habent admirationis, cum prope accesseris?</a> Rhetorice igitur, inquam, nos mavis quam dialectice disputare? Sed tamen intellego quid velit. Scaevolam M. Immo alio genere; Quibus ego vehementer assentior. </p>\n\n<p>Efficiens dici potest. Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Itaque contra est, ac dicitis;</a> Certe, nisi voluptatem tanti aestimaretis. </p>\n\n<p>Illud non continuo, ut aeque incontentae. Quid autem habent admirationis, cum prope accesseris? Equidem, sed audistine modo de Carneade? Eaedem res maneant alio modo. <a href=\"http://loripsum.net/\" target=\"_blank\">Neutrum vero, inquit ille.</a> Aliter homines, aliter philosophos loqui putas oportere? </p>',NULL,NULL,NULL,NULL,1,1,22,0,0,NULL,'Inherit','Inherit',11),
	(81,27,4,0,1,0,'','2013-07-03 21:10:21','2013-07-03 21:24:37','energy','Energy',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. At eum nihili facit; Hoc loco tenere se Triarius non potuit. Bonum incolumis acies: misera caecitas. Tum ille: Ain tandem? Primum in nostrane potestate est, quid meminerimus? </p>\n\n<p>Istic sum, inquit. Nulla erit controversia. Restinguet citius, si ardentem acceperit. Itaque ab his ordiamur. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quid autem habent admirationis, cum prope accesseris?</a> Rhetorice igitur, inquam, nos mavis quam dialectice disputare? Sed tamen intellego quid velit. Scaevolam M. Immo alio genere; Quibus ego vehementer assentior. </p>\n\n<p>Efficiens dici potest. Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Itaque contra est, ac dicitis;</a> Certe, nisi voluptatem tanti aestimaretis. </p>\n\n<p>Illud non continuo, ut aeque incontentae. Quid autem habent admirationis, cum prope accesseris? Equidem, sed audistine modo de Carneade? Eaedem res maneant alio modo. <a href=\"http://loripsum.net/\" target=\"_blank\">Neutrum vero, inquit ille.</a> Aliter homines, aliter philosophos loqui putas oportere? </p>',NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(82,28,3,0,1,0,'','2013-07-03 21:10:22','2013-07-03 21:24:40','packaging','Packaging',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Qualem igitur hominem natura inchoavit?</a> Cur id non ita fit? </p>\n\n<p>Non potes, nisi retexueris illa. Videsne quam sit magna dissensio? Avaritiamne minuis? Duo Reges: constructio interrete. Ut pulsi recurrant? Confecta res esset. </p>\n\n<p>Hoc ipsum elegantius poni meliusque potuit. Audeo dicere, inquit. Prioris generis est docilitas, memoria; Minime vero, inquit ille, consentit. Si quae forte-possumus. Quare attende, quaeso. Sed ille, ut dixi, vitiose. Venit ad extremum; </p>\n\n<p>Eam stabilem appellas. Praeteritis, inquit, gaudeo. <a href=\"http://loripsum.net/\" target=\"_blank\">Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse;</a> Quibus ego vehementer assentior. Nunc agendum est subtilius. </p>\n\n<p>Certe non potest. Addidisti ad extremum etiam indoctum fuisse. Igitur ne dolorem quidem. Praeteritis, inquit, gaudeo. Sit enim idem caecus, debilis. Hic ambiguo ludimur. </p>',NULL,NULL,NULL,NULL,1,1,23,0,0,NULL,'Inherit','Inherit',11),
	(83,28,4,0,1,0,'','2013-07-03 21:10:22','2013-07-03 21:24:41','packaging','Packaging',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Qualem igitur hominem natura inchoavit?</a> Cur id non ita fit? </p>\n\n<p>Non potes, nisi retexueris illa. Videsne quam sit magna dissensio? Avaritiamne minuis? Duo Reges: constructio interrete. Ut pulsi recurrant? Confecta res esset. </p>\n\n<p>Hoc ipsum elegantius poni meliusque potuit. Audeo dicere, inquit. Prioris generis est docilitas, memoria; Minime vero, inquit ille, consentit. Si quae forte-possumus. Quare attende, quaeso. Sed ille, ut dixi, vitiose. Venit ad extremum; </p>\n\n<p>Eam stabilem appellas. Praeteritis, inquit, gaudeo. <a href=\"http://loripsum.net/\" target=\"_blank\">Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse;</a> Quibus ego vehementer assentior. Nunc agendum est subtilius. </p>\n\n<p>Certe non potest. Addidisti ad extremum etiam indoctum fuisse. Igitur ne dolorem quidem. Praeteritis, inquit, gaudeo. Sit enim idem caecus, debilis. Hic ambiguo ludimur. </p>',NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',11),
	(84,29,3,0,1,0,'','2013-07-03 21:10:23','2013-07-03 21:24:44','resellers','Resellers',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tum ille: Ain tandem? <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Duo Reges: constructio interrete. Age sane, inquam. Laboro autem non sine causa; Sed haec omittamus; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Tollenda est atque extrahenda radicitus.</a> Non igitur bene. Peccata paria. </p>\n\n<p>Teneo, inquit, finem illi videri nihil dolere. Eam stabilem appellas. </p>\n\n<p>Perge porro; Respondent extrema primis, media utrisque, omnia omnibus. Quorum sine causa fieri nihil putandum est. Compensabatur, inquit, cum summis doloribus laetitia. </p>\n\n<p>Age sane, inquam. Zenonis est, inquam, hoc Stoici. </p>',NULL,NULL,NULL,NULL,1,1,24,0,0,NULL,'Inherit','Inherit',11),
	(85,29,4,0,1,0,'','2013-07-03 21:10:23','2013-07-03 21:24:44','resellers','Resellers',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tum ille: Ain tandem? <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Duo Reges: constructio interrete. Age sane, inquam. Laboro autem non sine causa; Sed haec omittamus; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Tollenda est atque extrahenda radicitus.</a> Non igitur bene. Peccata paria. </p>\n\n<p>Teneo, inquit, finem illi videri nihil dolere. Eam stabilem appellas. </p>\n\n<p>Perge porro; Respondent extrema primis, media utrisque, omnia omnibus. Quorum sine causa fieri nihil putandum est. Compensabatur, inquit, cum summis doloribus laetitia. </p>\n\n<p>Age sane, inquam. Zenonis est, inquam, hoc Stoici. </p>',NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',11),
	(86,31,1,0,1,0,'Page','2013-07-03 21:27:57','2013-07-03 21:27:57','new-page','New Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,26,0,0,NULL,'Inherit','Inherit',0),
	(87,31,2,1,1,1,'Page','2013-07-03 21:27:57','2013-07-03 21:28:08','resellers','Resellers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,26,0,0,NULL,'Inherit','Inherit',0),
	(88,31,3,0,1,0,'Page','2013-07-03 21:27:57','2013-07-03 21:28:15','resellers','Resellers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',0),
	(89,11,2,0,1,0,'','2013-07-03 21:09:38','2013-07-03 21:28:24','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(90,8,2,0,1,0,'Page','2013-07-03 21:09:34','2013-07-03 21:28:31','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> </p>\n\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas. </p>\n\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum? </p>\n\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí? </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',7),
	(91,8,3,1,1,1,'Page','2013-07-03 21:09:34','2013-07-03 21:28:31','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> </p>\n\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas. </p>\n\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum? </p>\n\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí? </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',7),
	(92,9,2,0,1,0,'Page','2013-07-03 21:09:36','2013-07-03 21:28:39','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete. </p>\n\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius. </p>\n\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit? </p>\n\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit. </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',7),
	(93,9,3,1,1,1,'Page','2013-07-03 21:09:36','2013-07-03 21:28:39','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete. </p>\n\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius. </p>\n\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit? </p>\n\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',7),
	(94,10,2,0,1,0,'Page','2013-07-03 21:09:37','2013-07-03 21:28:48','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis. </p>\n\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem. </p>\n\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita. </p>\n\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum. </p>\n\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat; </p>',NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',7),
	(95,10,3,1,1,1,'Page','2013-07-03 21:09:37','2013-07-03 21:28:49','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis. </p>\n\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem. </p>\n\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita. </p>\n\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum. </p>\n\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',7),
	(96,32,1,0,1,0,'Page','2013-07-03 21:29:48','2013-07-03 21:29:48','new-page','New Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',0),
	(97,32,2,1,1,1,'Page','2013-07-03 21:29:48','2013-07-03 21:30:04','refer-us','Refer Us',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',0),
	(98,32,3,0,1,0,'Page','2013-07-03 21:29:48','2013-07-03 21:30:25','refer-us','Refer Us',NULL,NULL,NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',0),
	(99,33,1,1,1,1,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','page-not-found','Page not found',NULL,'<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p>\n<p>Please check the spelling of the URL you were trying to access and try again.</p>',NULL,NULL,NULL,NULL,0,0,7,0,0,NULL,'Inherit','Inherit',0),
	(100,34,1,1,1,1,'ErrorPage','2013-07-03 21:33:20','2013-07-03 21:33:20','server-error','Server error',NULL,'<p>Sorry, there was a problem handling your request.</p>',NULL,NULL,NULL,NULL,0,0,8,0,0,NULL,'Inherit','Inherit',0),
	(101,35,1,1,1,1,'BlogHolder','2013-07-06 17:25:00','2013-07-06 17:25:00','blog','Blog',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',0),
	(102,36,1,1,1,1,'BlogEntry','2013-07-06 17:25:00','2013-07-06 17:25:00','sample-blog-entry','SilverStripe blog module successfully installed',NULL,'Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog (such as the widgets displayed in the sidebar) in [url=admin]the CMS[/url].',NULL,NULL,NULL,NULL,0,1,0,0,0,NULL,'Inherit','Inherit',35),
	(103,11,3,1,1,1,'Page','2013-07-03 21:09:38','2013-07-06 17:48:28','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(104,11,4,1,1,1,'Page','2013-07-03 21:09:38','2013-07-06 17:48:35','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,0,1,3,0,0,NULL,'Inherit','Inherit',0),
	(105,11,5,1,1,1,'Page','2013-07-03 21:09:38','2013-07-06 17:48:40','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,0,0,3,0,0,NULL,'Inherit','Inherit',0),
	(106,17,5,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 17:48:57','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(107,17,6,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 17:48:57','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',0),
	(108,18,5,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 17:49:01','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',0),
	(109,18,6,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 17:49:01','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',0),
	(110,17,7,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 17:49:15','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11),
	(111,17,8,1,1,1,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 17:49:16','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis; </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a> </p>\n\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit; </p>\n\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse. </p>',NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',11),
	(112,18,7,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 17:49:23','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(113,18,8,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 17:49:23','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',11),
	(114,21,5,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 17:49:28','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11),
	(115,21,6,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 17:49:28','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',11),
	(116,20,5,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-06 17:49:32','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(117,20,6,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-06 17:49:32','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',11),
	(118,19,5,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 17:49:36','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(119,19,6,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 17:49:36','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',11),
	(120,16,5,1,1,1,'CaseStudyPage','2013-07-03 21:09:46','2013-07-06 17:51:08','oil-and-gas','Oil and Gas',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sint ista Graecorum; Cur iustitia laudatur? Tibi hoc incredibile, quod beatissimum. <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Profectus in exilium Tubulus statim nec respondere ausus; Quae duo sunt, unum facit. Optime, inquam. Duo Reges: constructio interrete. </p>\n\n<p>Sed quae tandem ista ratio est? Hic ambiguo ludimur. Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">De quibus cupio scire quid sentias.</a> Etiam beatissimum? Sint ista Graecorum; </p>\n\n<p>Quid me istud rogas? Rationis enim perfectio est virtus; Prave, nequiter, turpiter cenabat; Itaque ab his ordiamur. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur, nisi quod turpis oratio est?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Suo genere perveniant ad extremum;</a> </p>\n\n<p>Invidiosum nomen est, infame, suspectum. Prave, nequiter, turpiter cenabat; Et nemo nimium beatus est; Pugnant Stoici cum Peripateticis. </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',11),
	(121,17,9,1,1,1,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 18:47:56','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',11),
	(122,17,10,0,1,0,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 18:48:23','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',11),
	(123,17,11,1,1,1,'CaseStudyPage','2013-07-03 21:09:47','2013-07-06 18:48:30','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',11),
	(124,18,9,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 18:49:47','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(125,18,10,0,1,0,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 18:49:52','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio. </p>\n\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a> </p>\n\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit. </p>\n\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio? </p>\n\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(126,18,11,1,1,1,'CaseStudyPage','2013-07-03 21:09:52','2013-07-06 18:50:12','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio.</p>\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a></p>\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit.</p>\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio?</p>\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto;</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(127,19,7,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 18:50:37','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(128,19,8,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 18:51:04','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(129,19,9,0,1,0,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 18:51:15','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni? </p>\n\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a> </p>\n\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis. </p>\n\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem? </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto. </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(130,19,10,1,1,1,'CaseStudyPage','2013-07-03 21:09:57','2013-07-06 18:51:20','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni?</p>\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a></p>\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis.</p>\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem?</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto.</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',11),
	(131,21,7,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 18:52:18','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(132,21,8,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 18:52:25','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio? </p>\n\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur? </p>\n\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn. </p>\n\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est? </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(133,21,9,1,1,1,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 18:52:28','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio?</p>\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur?</p>\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a></p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn.</p>\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est?</p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(134,21,10,0,1,0,'CaseStudyPage','2013-07-03 21:10:08','2013-07-06 18:53:14','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio?</p>\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur?</p>\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a></p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn.</p>\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est?</p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',11),
	(135,20,7,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-06 18:53:37','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(136,20,8,0,1,0,'CaseStudyPage','2013-07-03 21:10:02','2013-07-06 18:53:45','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete. </p>\n\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis; </p>\n\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas. </p>\n\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane. </p>\n\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa. </p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(137,20,9,1,1,1,'CaseStudyPage','2013-07-03 21:10:02','2013-07-06 18:54:05','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete.</p>\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis;</p>\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas.</p>\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane.</p>\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa.</p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',11),
	(138,6,3,0,1,0,'HomePage','2013-07-03 21:09:07','2013-07-06 19:14:35','home','Home',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non risu potius quam oratione eiciendum? Rationis enim perfectio est virtus; </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Sed hoc sane concedamus. Quae ista amicitia est? <a href=\"http://loripsum.net/\" target=\"_blank\">Quid Zeno?</a> </p>\n\n<p>Aliter enim nosmet ipsos nosse non possumus. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Quo tandem modo? Tu quidem reddes; </p>\n\n<p>Confecta res esset. Primum quid tu dicis breve? Equidem e Cn. Res enim concurrent contrariae. <a href=\"http://loripsum.net/\" target=\"_blank\">Idem iste, inquam, de voluptate quid sentit?</a> </p>\n\n<p>Bestiarum vero nullum iudicium puto. An potest cupiditas finiri? Quippe: habes enim a rhetoribus; Memini vero, inquam; </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(139,6,4,0,1,0,'HomePage','2013-07-03 21:09:07','2013-07-06 19:14:54','home','Home',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non risu potius quam oratione eiciendum? Rationis enim perfectio est virtus; </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Sed hoc sane concedamus. Quae ista amicitia est? <a href=\"http://loripsum.net/\" target=\"_blank\">Quid Zeno?</a> </p>\n\n<p>Aliter enim nosmet ipsos nosse non possumus. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Quo tandem modo? Tu quidem reddes; </p>\n\n<p>Confecta res esset. Primum quid tu dicis breve? Equidem e Cn. Res enim concurrent contrariae. <a href=\"http://loripsum.net/\" target=\"_blank\">Idem iste, inquam, de voluptate quid sentit?</a> </p>\n\n<p>Bestiarum vero nullum iudicium puto. An potest cupiditas finiri? Quippe: habes enim a rhetoribus; Memini vero, inquam; </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(140,6,5,1,1,1,'HomePage','2013-07-03 21:09:07','2013-07-06 19:15:03','home','Home',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non risu potius quam oratione eiciendum? Rationis enim perfectio est virtus; </p>\n\n<p>Certe, nisi voluptatem tanti aestimaretis. Sed hoc sane concedamus. Quae ista amicitia est? <a href=\"http://loripsum.net/\" target=\"_blank\">Quid Zeno?</a> </p>\n\n<p>Aliter enim nosmet ipsos nosse non possumus. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Quo tandem modo? Tu quidem reddes; </p>\n\n<p>Confecta res esset. Primum quid tu dicis breve? Equidem e Cn. Res enim concurrent contrariae. <a href=\"http://loripsum.net/\" target=\"_blank\">Idem iste, inquam, de voluptate quid sentit?</a> </p>\n\n<p>Bestiarum vero nullum iudicium puto. An potest cupiditas finiri? Quippe: habes enim a rhetoribus; Memini vero, inquam; </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(141,6,6,1,1,1,'HomePage','2013-07-03 21:09:07','2013-07-06 19:15:27','home','Home',NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',0),
	(142,8,4,1,1,1,'SellingPage','2013-07-03 21:09:34','2013-07-07 16:56:28','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> </p>\n\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas. </p>\n\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum? </p>\n\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí? </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',7),
	(143,8,5,0,1,0,'SellingPage','2013-07-03 21:09:34','2013-07-07 16:57:16','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> </p>\n\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas. </p>\n\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum? </p>\n\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí? </p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',7),
	(144,8,6,1,1,1,'SellingPage','2013-07-03 21:09:34','2013-07-07 16:57:19','benefits','Benefits',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed videbimus.</a> Ut pulsi recurrant? A mene tu? <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a></p>\n<p>Ut pulsi recurrant? Quae cum dixisset, finem ille. <a href=\"http://loripsum.net/\" target=\"_blank\">Quae contraria sunt his, malane?</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis;</a> Hic ambiguo ludimur. Bonum incolumis acies: misera caecitas.</p>\n<p>Magna laus. Itaque fecimus. Restatis igitur vos; Deinde dolorem quem maximum?</p>\n<p>Apparet statim, quae sint officia, quae actiones. Paria sunt igitur. Rationis enim perfectio est virtus; Illi enim inter se dissentiunt. Certe non potest. <a href=\"http://loripsum.net/\" target=\"_blank\">Nam quid possumus facere melius?</a> Moriatur, inquit.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Ergo, inquit, tibi Q.</a> Eam tum adesse, cum dolor omnis absit; Utram tandem linguam nescio? Sedulo, inquam, faciam. In schola desinis. Graccho, eius fere, aequalí?</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',7),
	(145,9,4,1,1,1,'SellingPage','2013-07-03 21:09:36','2013-07-07 16:57:41','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete. </p>\n\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius. </p>\n\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit? </p>\n\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',7),
	(146,9,5,0,1,0,'SellingPage','2013-07-03 21:09:36','2013-07-07 16:59:57','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete. </p>\n\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius. </p>\n\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit? </p>\n\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit. </p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',7),
	(147,9,6,1,1,1,'SellingPage','2013-07-03 21:09:36','2013-07-07 17:00:01','products','Products',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quod equidem non reprehendo; Ac tamen hic mallet non dolere. Sed mehercule pergrata mihi oratio tua. Duo Reges: constructio interrete.</p>\n<p>Ille enim occurrentia nescio quae comminiscebatur; A mene tu? Age sane, inquam. <a href=\"http://loripsum.net/\" target=\"_blank\">At coluit ipse amicitias.</a> Quid Zeno? Nihil opus est exemplis hoc facere longius.</p>\n<p>Sed ego in hoc resisto; Erat enim Polemonis. <a href=\"http://loripsum.net/\" target=\"_blank\">Traditur, inquit, ab Epicuro ratio neglegendi doloris.</a> Tum Torquatus: Prorsus, inquit, assentior; Qualem igitur hominem natura inchoavit?</p>\n<p>Qualem igitur hominem natura inchoavit? Itaque contra est, ac dicitis; Sed videbimus. Nunc vides, quid faciat.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Iam in altera philosophiae parte. Tibi hoc incredibile, quod beatissimum. Si quae forte-possumus. Quid ad utilitatem tantae pecuniae? Nihilo magis. Istic sum, inquit.</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',7),
	(148,10,4,1,1,1,'SellingPage','2013-07-03 21:09:37','2013-07-07 17:00:19','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis. </p>\n\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem. </p>\n\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita. </p>\n\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum. </p>\n\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',7),
	(149,10,5,0,1,0,'SellingPage','2013-07-03 21:09:37','2013-07-07 17:00:47','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis. </p>\n\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem. </p>\n\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita. </p>\n\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum. </p>\n\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat; </p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',7),
	(150,10,6,1,1,1,'SellingPage','2013-07-03 21:09:37','2013-07-07 17:00:49','connect-with-us','Connect With Us',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Que Manilium, ab iisque M. <a href=\"http://loripsum.net/\" target=\"_blank\">Igitur ne dolorem quidem.</a> Praeteritis, inquit, gaudeo. Pugnant Stoici cum Peripateticis.</p>\n<p>Bonum integritas corporis: misera debilitas. Sed nunc, quod agimus; Hic nihil fuit, quod quaereremus. Sed nimis multa. At enim sequor utilitatem.</p>\n<p>Est, ut dicis, inquam. Bonum incolumis acies: misera caecitas. Satis est ad hoc responsum. Tum Triarius: Posthac quidem, inquit, audacius. Disserendi artem nullam habuit. Utram tandem linguam nescio? Utilitatis causa amicitia est quaesita.</p>\n<p>Duo Reges: constructio interrete. <a href=\"http://loripsum.net/\" target=\"_blank\">Haec para/doca illi, nos admirabilia dicamus.</a> Nos cum te, M. Est, ut dicis, inquit; Erat enim res aperta. Sed ille, ut dixi, vitiose. Quaerimus enim finem bonorum.</p>\n<p>Ut id aliis narrare gestiant? Quae est igitur causa istarum angustiarum? Sed virtutem ipsam inchoavit, nihil amplius. Primum in nostrane potestate est, quid meminerimus? Nam quid possumus facere melius? Et quidem, inquit, vehementer errat;</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',7),
	(151,37,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 21:56:13','2013-07-07 21:56:13','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',11),
	(152,37,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 21:56:13','2013-07-07 22:03:18','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',11),
	(153,37,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 21:56:13','2013-07-07 22:03:30','transport','Transport',NULL,NULL,NULL,NULL,NULL,NULL,1,1,6,0,0,NULL,'Inherit','Inherit',11),
	(154,38,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:03:42','2013-07-07 22:03:42','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',11),
	(155,38,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:03:42','2013-07-07 22:04:21','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',11),
	(156,38,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:03:42','2013-07-07 22:04:36','agriculture','Agriculture',NULL,NULL,NULL,NULL,NULL,NULL,1,1,7,0,0,NULL,'Inherit','Inherit',11),
	(157,39,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:04:47','2013-07-07 22:04:47','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',11),
	(158,39,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:04:47','2013-07-07 22:06:55','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',11),
	(159,39,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:04:47','2013-07-07 22:07:00','mining','Mining',NULL,NULL,NULL,NULL,NULL,NULL,1,1,8,0,0,NULL,'Inherit','Inherit',11),
	(160,40,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:07:09','2013-07-07 22:07:09','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',11),
	(161,40,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:07:09','2013-07-07 22:07:41','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',11),
	(162,40,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:07:09','2013-07-07 22:07:43','infrastructure','Infrastructure',NULL,NULL,NULL,NULL,NULL,NULL,1,1,9,0,0,NULL,'Inherit','Inherit',11),
	(163,41,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:07:52','2013-07-07 22:07:52','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',11),
	(164,41,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:07:52','2013-07-07 22:08:11','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',11),
	(165,41,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:07:52','2013-07-07 22:08:14','oil-and-gas','Oil & Gas',NULL,NULL,NULL,NULL,NULL,NULL,1,1,10,0,0,NULL,'Inherit','Inherit',11),
	(166,42,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:08:30','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(167,42,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:08:50','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(168,42,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:08:53','local-government','Local Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(169,42,4,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:10:56','local-government','Local Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(170,42,5,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:08:30','2013-07-07 22:12:05','local-government','Local Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,11,0,0,NULL,'Inherit','Inherit',11),
	(171,43,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:12:24','2013-07-07 22:12:24','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',11),
	(172,43,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:12:24','2013-07-07 22:13:33','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',11),
	(173,43,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:12:24','2013-07-07 22:13:36','manufacture-and-process','Manufacture & Process',NULL,NULL,NULL,NULL,NULL,NULL,1,1,12,0,0,NULL,'Inherit','Inherit',11),
	(174,44,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:13:44','2013-07-07 22:13:44','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',11),
	(175,44,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:13:44','2013-07-07 22:14:07','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',11),
	(176,44,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:13:44','2013-07-07 22:14:10','central-government','Central Government',NULL,NULL,NULL,NULL,NULL,NULL,1,1,13,0,0,NULL,'Inherit','Inherit',11),
	(177,45,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:14:33','2013-07-07 22:14:33','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',11),
	(178,45,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:14:33','2013-07-07 22:14:52','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',11),
	(179,45,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:14:33','2013-07-07 22:14:54','defence','Defence',NULL,NULL,NULL,NULL,NULL,NULL,1,1,14,0,0,NULL,'Inherit','Inherit',11),
	(180,46,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:15:00','2013-07-07 22:15:00','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',11),
	(181,46,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:15:00','2013-07-07 22:15:15','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',11),
	(182,46,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:15:00','2013-07-07 22:15:17','services','Services',NULL,NULL,NULL,NULL,NULL,NULL,1,1,15,0,0,NULL,'Inherit','Inherit',11),
	(183,47,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:15:29','2013-07-07 22:15:29','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',11),
	(184,47,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:15:29','2013-07-07 22:16:10','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',11),
	(185,47,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:15:29','2013-07-07 22:16:14','energy','Energy',NULL,NULL,NULL,NULL,NULL,NULL,1,1,16,0,0,NULL,'Inherit','Inherit',11),
	(186,48,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:16:22','2013-07-07 22:16:22','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',11),
	(187,48,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:16:22','2013-07-07 22:16:39','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',11),
	(188,48,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:16:22','2013-07-07 22:17:09','packaging','Packaging',NULL,NULL,NULL,NULL,NULL,NULL,1,1,17,0,0,NULL,'Inherit','Inherit',11),
	(189,49,1,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:17:20','2013-07-07 22:17:20','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',11),
	(190,49,2,0,1,0,'CaseStudyCategoriesPage','2013-07-07 22:17:20','2013-07-07 22:17:43','new-case-study-categories-page','New Case Study Categories Page',NULL,NULL,NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',11),
	(191,49,3,1,1,1,'CaseStudyCategoriesPage','2013-07-07 22:17:20','2013-07-07 22:17:46','resllers','Resllers',NULL,NULL,NULL,NULL,NULL,NULL,1,1,18,0,0,NULL,'Inherit','Inherit',11),
	(192,17,12,1,1,1,'CaseStudyPage','2013-07-03 21:09:47','2013-07-07 22:18:04','bp','BP',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Immo alio genere; Nihil illinc huc pervenit. Erit enim mecum, si tecum erit. Duo Reges: constructio interrete.</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quaerimus enim finem bonorum.</a> Minime vero, inquit ille, consentit. Itaque contra est, ac dicitis;</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Conferam avum tuum Drusum cum C.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">At, si voluptas esset bonum, desideraret.</a></p>\n<p>Non est igitur voluptas bonum. Haec dicuntur fortasse ieiunius; Hic nihil fuit, quod quaereremus. Pauca mutat vel plura sane; Est, ut dicis, inquit;</p>\n<p>Confecta res esset. Nihil sane. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Ecce aliud simile dissimile.</a> Avaritiamne minuis? Ea possunt paria non esse.</p>',NULL,NULL,NULL,NULL,1,1,1,0,0,NULL,'Inherit','Inherit',41),
	(193,18,12,1,1,1,'CaseStudyPage','2013-07-03 21:09:52','2013-07-07 22:18:13','local-government-thames','Local Government - Thames',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid autem habent admirationis, cum prope accesseris? Proclivi currit oratio.</p>\n<p>Utilitatis causa amicitia est quaesita. Recte, inquit, intellegis. Tum mihi Piso: Quid ergo? <a href=\"http://loripsum.net/\" target=\"_blank\">Hoc non est positum in nostra actione.</a></p>\n<p>Haec para/doca illi, nos admirabilia dicamus. Duo Reges: constructio interrete. Verum hoc idem saepe faciamus. At multis se probavit.</p>\n<p>Nulla erit controversia. Est, ut dicis, inquam. Immo alio genere; Ita credo. <a href=\"http://loripsum.net/\" target=\"_blank\">Tria genera bonorum;</a> Quae contraria sunt his, malane? Utram tandem linguam nescio?</p>\n<p>Urgent tamen et nihil remittunt. Non igitur bene. Quare attende, quaeso. Age, inquies, ista parva sunt. Sed ego in hoc resisto;</p>',NULL,NULL,NULL,NULL,1,1,2,0,0,NULL,'Inherit','Inherit',41),
	(194,19,11,1,1,1,'CaseStudyPage','2013-07-03 21:09:57','2013-07-07 22:18:18','nz-transport-agency','NZ Transport Agency',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Cur haec eadem Democritus?</a> Sit enim idem caecus, debilis. Nunc omni virtuti vitium contrario nomine opponitur. Quid ait Aristoteles reliquique Platonis alumni?</p>\n<p>Quis istud possit, inquit, negare? Nihil ad rem! Ne sit sane; Scrupulum, inquam, abeunti; Videamus animi partes, quarum est conspectus illustrior; <a href=\"http://loripsum.net/\" target=\"_blank\">Poterat autem inpune;</a></p>\n<p>Haec dicuntur fortasse ieiunius; Duo Reges: constructio interrete. Audeo dicere, inquit. At certe gravius. Recte, inquit, intellegis.</p>\n<p>Ita nemo beato beatior. Idemne, quod iucunde? Ita nemo beato beatior. Rationis enim perfectio est virtus; Torquatus, is qui consul cum Cn. Tum ille: Ain tandem?</p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Utilitatis causa amicitia est quaesita.</a> De illis, cum volemus. Illa tamen simplicia, vestra versuta. Restatis igitur vos; Aliter enim explicari, quod quaeritur, non potest. Bestiarum vero nullum iudicium puto.</p>',NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',41),
	(195,20,10,1,1,1,'CaseStudyPage','2013-07-03 21:10:02','2013-07-07 22:18:23','landcorp','LandCorp',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href=\"http://loripsum.net/\" target=\"_blank\">Sed ad bona praeterita redeamus.</a> Beatus sibi videtur esse moriens. At enim sequor utilitatem. Igitur ne dolorem quidem. Quid adiuvas? Duo Reges: constructio interrete.</p>\n<p>Illi enim inter se dissentiunt. Memini vero, inquam; Non autem hoc: igitur ne illud quidem. <a href=\"http://loripsum.net/\" target=\"_blank\">Ut aliquid scire se gaudeant?</a> An eiusdem modi? Sed fortuna fortis;</p>\n<p>Laboro autem non sine causa; Qua tu etiam inprudens utebare non numquam. Eam stabilem appellas.</p>\n<p>Cur iustitia laudatur? <a href=\"http://loripsum.net/\" target=\"_blank\">Nescio quo modo praetervolavit oratio.</a> Quippe: habes enim a rhetoribus; Sed tu istuc dixti bene Latine, parum plane.</p>\n<p>Non potes, nisi retexueris illa. Bonum incolumis acies: misera caecitas. Quae cum dixisset paulumque institisset, Quid est? Philosophi autem in suis lectulis plerumque moriuntur. Sed ad illum redeo. Non potes, nisi retexueris illa.</p>',NULL,NULL,NULL,NULL,1,1,4,0,0,NULL,'Inherit','Inherit',41),
	(196,21,11,1,1,1,'CaseStudyPage','2013-07-03 21:10:08','2013-07-07 22:18:28','mighty-river-power','Mighty River Power',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis enim redargueret? Poterat autem inpune; Tubulo putas dicere? Duo Reges: constructio interrete. Sed haec omittamus; Rationis enim perfectio est virtus; <a href=\"http://loripsum.net/\" target=\"_blank\">An tu me de L.</a> Gerendus est mos, modo recte sentiat. Utram tandem linguam nescio?</p>\n<p>Ea possunt paria non esse. Ut aliquid scire se gaudeant? Quis hoc dicit? Memini vero, inquam; Cur iustitia laudatur?</p>\n<p>Ita prorsus, inquam; Quod quidem nobis non saepe contingit. <a href=\"http://loripsum.net/\" target=\"_blank\">Si longus, levis.</a> Quis hoc dicit? Hic nihil fuit, quod quaereremus. <a href=\"http://loripsum.net/\" target=\"_blank\">Praeclare hoc quidem.</a></p>\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Quae cum essent dicta, discessimus.</a> Peccata paria. <a href=\"http://loripsum.net/\" target=\"_blank\">Hic ambiguo ludimur.</a> Non laboro, inquit, de nomine. Quid iudicant sensus? Beatus sibi videtur esse moriens. Equidem e Cn.</p>\n<p>Iam in altera philosophiae parte. Id est enim, de quo quaerimus. Quis istud possit, inquit, negare? Contineo me ab exemplis. Sed quae tandem ista ratio est?</p>',NULL,NULL,NULL,NULL,1,1,5,0,0,NULL,'Inherit','Inherit',41),
	(197,11,6,1,1,1,'VirtualPage','2013-07-03 21:09:38','2013-07-07 22:27:26','case-studies','Case Studies',NULL,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter autem vobis placet. Quis non odit sordidos, vanos, leves, futtiles? Sed quid sentiat, non videtis. At hoc in eo M. <a href=\"http://loripsum.net/\" target=\"_blank\">Duo Reges: constructio interrete.</a> Itaque his sapiens semper vacabit. </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Non igitur bene.</a> <a href=\"http://loripsum.net/\" target=\"_blank\">Sed haec omittamus;</a> </p>\n\n<p><a href=\"http://loripsum.net/\" target=\"_blank\">Vide, quantum, inquam, fallare, Torquate.</a> Efficiens dici potest. Omnes enim iucundum motum, quo sensus hilaretur. Sed nunc, quod agimus; </p>\n\n<p>Nos cum te, M. Ostendit pedes et pectus. Sed nunc, quod agimus; Beatum, inquit. Audeo dicere, inquit. Qui-vere falsone, quaerere mittimus-dicitur oculis se privasse; Sed hoc sane concedamus. <a href=\"http://loripsum.net/\" target=\"_blank\">Faceres tu quidem, Torquate, haec omnia;</a> </p>\n\n<p>Inde igitur, inquit, ordiendum est. Sin aliud quid voles, postea. A mene tu? Respondeat totidem verbis. </p>',NULL,NULL,NULL,NULL,1,0,3,0,0,NULL,'Inherit','Inherit',0),
	(198,11,7,0,1,0,'VirtualPage','2013-07-03 21:09:38','2013-07-07 22:27:48','home-2','Home',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(199,11,8,1,1,1,'Page','2013-07-03 21:09:38','2013-07-07 22:28:12','home-2','Home',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(200,11,9,1,1,1,'Page','2013-07-03 21:09:38','2013-07-07 22:28:30','home-2','Case Studies',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0),
	(201,6,7,1,1,1,'HomePage','2013-07-03 21:09:07','2013-07-07 22:29:51','home','Home',NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,NULL,'Inherit','Inherit',0),
	(202,11,10,1,1,1,'Page','2013-07-03 21:09:38','2013-07-07 22:32:36','case-studies','Case Studies',NULL,NULL,NULL,NULL,NULL,NULL,1,1,3,0,0,NULL,'Inherit','Inherit',0);

/*!40000 ALTER TABLE `SiteTree_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table SiteTree_ViewerGroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SiteTree_ViewerGroups`;

CREATE TABLE `SiteTree_ViewerGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table Social
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Social`;

CREATE TABLE `Social` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Social') CHARACTER SET utf8 DEFAULT 'Social',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `IconID` int(11) NOT NULL DEFAULT '0',
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IconID` (`IconID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `Social` WRITE;
/*!40000 ALTER TABLE `Social` DISABLE KEYS */;

INSERT INTO `Social` (`ID`, `ClassName`, `Created`, `LastEdited`, `Link`, `Name`, `IconID`, `SiteConfigID`)
VALUES
	(1,'Social','2013-07-06 15:35:03','2013-07-06 15:36:20','https://www.facebook.com/','Facebook',13,1),
	(2,'Social','2013-07-06 15:37:40','2013-07-06 15:37:53','http://nz.linkedin.com/','Linkedin',14,1),
	(3,'Social','2013-07-06 15:39:24','2013-07-06 15:47:57','mailto:info@csvue.co.nz','E-mail',15,1);

/*!40000 ALTER TABLE `Social` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table StaffMember
# ------------------------------------------------------------

DROP TABLE IF EXISTS `StaffMember`;

CREATE TABLE `StaffMember` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('StaffMember') CHARACTER SET utf8 DEFAULT 'StaffMember',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `JobTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Info` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `AboutPageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `PhotoID` (`PhotoID`),
  KEY `AboutPageID` (`AboutPageID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `StaffMember` WRITE;
/*!40000 ALTER TABLE `StaffMember` DISABLE KEYS */;

INSERT INTO `StaffMember` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `JobTitle`, `Info`, `PhotoID`, `AboutPageID`)
VALUES
	(1,'StaffMember','2013-07-03 21:09:09','2013-07-03 21:09:13','De vacuitate doloris eadem sententia erit. Ille','Quod quidem nobis non saepe contingit. Ostendit pedes','Non igitur',2,7),
	(2,'StaffMember','2013-07-03 21:09:13','2013-07-03 21:09:17','Sed residamus,','Istic sum, inquit. Si quae forte-possumus. Respondeat','Sed ego in hoc resisto; Iam',5,7),
	(3,'StaffMember','2013-07-03 21:09:17','2013-07-03 21:09:21','Inquit, dasne adolescenti veniam?','Sit enim idem','Quare attende, quaeso.',2,7),
	(4,'StaffMember','2013-07-03 21:09:21','2013-07-03 21:09:25','Nihilo magis. Dat enim intervalla et','Aliter homines,','Bonum liberi: misera',3,7),
	(5,'StaffMember','2013-07-03 21:09:25','2013-07-03 21:09:28','Quod ea non occurrentia fingunt,','Sequitur disserendi ratio cognitioque naturae;','Hic nihil fuit,',3,7),
	(6,'StaffMember','2013-07-03 21:09:28','2013-07-03 21:09:33','Minime vero, inquit ille, consentit. Quae sequuntur igitur?','Si enim ad populum me vocas, eum.','Omnia peccata paria dicitis. Magna laus. Quid',4,7);

/*!40000 ALTER TABLE `StaffMember` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table VirtualPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `VirtualPage`;

CREATE TABLE `VirtualPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `VirtualPage` WRITE;
/*!40000 ALTER TABLE `VirtualPage` DISABLE KEYS */;

INSERT INTO `VirtualPage` (`ID`, `VersionID`, `CopyContentFromID`)
VALUES
	(11,0,6);

/*!40000 ALTER TABLE `VirtualPage` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table VirtualPage_Live
# ------------------------------------------------------------

DROP TABLE IF EXISTS `VirtualPage_Live`;

CREATE TABLE `VirtualPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `VirtualPage_Live` WRITE;
/*!40000 ALTER TABLE `VirtualPage_Live` DISABLE KEYS */;

INSERT INTO `VirtualPage_Live` (`ID`, `VersionID`, `CopyContentFromID`)
VALUES
	(11,0,0);

/*!40000 ALTER TABLE `VirtualPage_Live` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table VirtualPage_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `VirtualPage_versions`;

CREATE TABLE `VirtualPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `VirtualPage_versions` WRITE;
/*!40000 ALTER TABLE `VirtualPage_versions` DISABLE KEYS */;

INSERT INTO `VirtualPage_versions` (`ID`, `RecordID`, `Version`, `VersionID`, `CopyContentFromID`)
VALUES
	(1,11,6,0,0),
	(2,11,7,0,6);

/*!40000 ALTER TABLE `VirtualPage_versions` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
